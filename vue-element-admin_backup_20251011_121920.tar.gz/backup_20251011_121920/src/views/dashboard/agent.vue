<template>
  <div class="dashboard-container">
    <div class="dashboard-text">
      <h1>{{ $t('dashboard.agentWelcome') }}</h1>
      <p>{{ $t('dashboard.agentDescription') }}</p>
    </div>

    <!-- 代理统计卡片 -->
    <el-row :gutter="40" class="panel-group">
      <el-col :xs="12" :sm="12" :lg="6" class="card-panel-col">
        <div class="card-panel">
          <div class="card-panel-icon-wrapper icon-people">
            <svg-icon icon-class="peoples" class-name="card-panel-icon" />
          </div>
          <div class="card-panel-description">
            <div class="card-panel-text">{{ $t('dashboard.bindUsers') }}</div>
            <count-to :start-val="0" :end-val="agentStats.bindUsers" :duration="2600" class="card-panel-num" />
          </div>
        </div>
      </el-col>

      <el-col :xs="12" :sm="12" :lg="6" class="card-panel-col">
        <div class="card-panel">
          <div class="card-panel-icon-wrapper icon-money">
            <svg-icon icon-class="money" class-name="card-panel-icon" />
          </div>
          <div class="card-panel-description">
            <div class="card-panel-text">{{ $t('dashboard.totalCommission') }}</div>
            <count-to :start-val="0" :end-val="agentStats.totalCommission" :duration="3000" class="card-panel-num" />
          </div>
        </div>
      </el-col>

      <el-col :xs="12" :sm="12" :lg="6" class="card-panel-col">
        <div class="card-panel">
          <div class="card-panel-icon-wrapper icon-shopping">
            <svg-icon icon-class="shopping" class-name="card-panel-icon" />
          </div>
          <div class="card-panel-description">
            <div class="card-panel-text">{{ $t('dashboard.monthlyOrders') }}</div>
            <count-to :start-val="0" :end-val="agentStats.monthlyOrders" :duration="3200" class="card-panel-num" />
          </div>
        </div>
      </el-col>

      <el-col :xs="12" :sm="12" :lg="6" class="card-panel-col">
        <div class="card-panel">
          <div class="card-panel-icon-wrapper icon-message">
            <svg-icon icon-class="message" class-name="card-panel-icon" />
          </div>
          <div class="card-panel-description">
            <div class="card-panel-text">{{ $t('dashboard.commissionRate') }}</div>
            <count-to :start-val="0" :end-val="agentStats.commissionRate" :duration="2800" class="card-panel-num" />
          </div>
        </div>
      </el-col>
    </el-row>

    <!-- 代理功能快捷入口 -->
    <el-row :gutter="20" style="margin-top: 30px;">
      <el-col :span="12">
        <el-card class="box-card">
          <div slot="header" class="clearfix">
            <span>{{ $t('dashboard.agentActions') }}</span>
          </div>
          <div class="action-buttons">
            <el-button type="primary" icon="el-icon-view" @click="goToCustomers">
              {{ $t('dashboard.viewCustomers') }}
            </el-button>
            <el-button type="success" icon="el-icon-shopping-cart-2" @click="goToOrders">
              {{ $t('dashboard.viewOrders') }}
            </el-button>
            <el-button type="warning" icon="el-icon-message" @click="goToFeedback">
              {{ $t('dashboard.viewFeedback') }}
            </el-button>
          </div>
        </el-card>
      </el-col>

      <el-col :span="12">
        <el-card class="box-card">
          <div slot="header" class="clearfix">
            <span>{{ $t('dashboard.recentActivity') }}</span>
          </div>
          <div class="activity-list">
            <div v-for="activity in recentActivities" :key="activity.id" class="activity-item">
              <i :class="activity.icon" :style="{ color: activity.color }" />
              <span class="activity-text">{{ activity.text }}</span>
              <span class="activity-time">{{ activity.time }}</span>
            </div>
          </div>
        </el-card>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import CountTo from 'vue-count-to'

export default {
  name: 'AgentDashboard',
  components: {
    CountTo
  },
  data() {
    return {
      agentStats: {
        bindUsers: 0,
        totalCommission: 0,
        monthlyOrders: 0,
        commissionRate: 0
      },
      recentActivities: [
        {
          id: 1,
          icon: 'el-icon-user',
          color: '#409EFF',
          text: '新客户注册',
          time: '2小时前'
        },
        {
          id: 2,
          icon: 'el-icon-shopping-cart-2',
          color: '#67C23A',
          text: '订单完成',
          time: '5小时前'
        },
        {
          id: 3,
          icon: 'el-icon-wallet',
          color: '#E6A23C',
          text: '佣金结算',
          time: '1天前'
        },
        {
          id: 4,
          icon: 'el-icon-message',
          color: '#F56C6C',
          text: '收到反馈',
          time: '2天前'
        }
      ]
    }
  },
  created() {
    this.loadAgentStats()
  },
  methods: {
    loadAgentStats() {
      // 从localStorage获取当前代理信息
      const currentUser = localStorage.getItem('currentUser')
      if (currentUser) {
        try {
          const userData = JSON.parse(currentUser)
          if (userData.type === 'agent') {
            this.loadAgentData(userData.id)
          }
        } catch (e) {
          console.error('解析用户数据失败:', e)
        }
      }
    },
    loadAgentData(agentId) {
      // 获取代理数据
      const savedAgents = localStorage.getItem('agentList')
      if (savedAgents) {
        try {
          const agents = JSON.parse(savedAgents)
          const agent = agents.find(a => a.id === agentId)
          if (agent) {
            this.agentStats.commissionRate = agent.commission || 0
            this.agentStats.totalCommission = agent.totalCommission || 0
            this.agentStats.bindUsers = agent.bindUsers || 0
          }
        } catch (e) {
          console.error('加载代理数据失败:', e)
        }
      }

      // 获取订单数据
      this.agentStats.monthlyOrders = Math.floor(Math.random() * 50) + 10
    },
    goToCustomers() {
      this.$router.push('/user/customer-list')
    },
    goToOrders() {
      this.$router.push('/order/list')
    },
    goToFeedback() {
      this.$router.push('/feedback/list')
    }
  }
}
</script>

<style lang="scss" scoped>
.dashboard-container {
  padding: 32px;
  background-color: rgb(240, 242, 245);
  position: relative;
}

.dashboard-text {
  text-align: center;
  margin-bottom: 40px;

  h1 {
    font-size: 28px;
    color: #2c3e50;
    margin-bottom: 10px;
  }

  p {
    font-size: 16px;
    color: #7f8c8d;
  }
}

.panel-group {
  margin-top: 18px;

  .card-panel-col {
    margin-bottom: 32px;
  }

  .card-panel {
    height: 108px;
    cursor: pointer;
    font-size: 12px;
    position: relative;
    overflow: hidden;
    color: #666;
    background: #fff;
    box-shadow: 4px 4px 40px rgba(0, 0, 0, .05);
    border-color: rgba(0, 0, 0, .05);
    border-radius: 4px;

    &:hover {
      .card-panel-icon-wrapper {
        color: #fff;
      }

      .icon-people {
        background: #40c9c6;
      }

      .icon-money {
        background: #36a3f7;
      }

      .icon-shopping {
        background: #f4516c;
      }

      .icon-message {
        background: #34bfa3;
      }
    }

    .icon-people {
      color: #40c9c6;
    }

    .icon-money {
      color: #36a3f7;
    }

    .icon-shopping {
      color: #f4516c;
    }

    .icon-message {
      color: #34bfa3;
    }

    .card-panel-icon-wrapper {
      float: left;
      margin: 14px 0 0 14px;
      padding: 16px;
      transition: all 0.38s ease-out;
      border-radius: 6px;
    }

    .card-panel-icon {
      float: left;
      font-size: 48px;
    }

    .card-panel-description {
      float: right;
      font-weight: bold;
      margin: 26px;
      margin-left: 0px;

      .card-panel-text {
        line-height: 18px;
        color: rgba(0, 0, 0, 0.45);
        font-size: 16px;
        margin-bottom: 12px;
      }

      .card-panel-num {
        font-size: 20px;
      }
    }
  }
}

.box-card {
  .action-buttons {
    display: flex;
    flex-direction: column;
    gap: 10px;
  }

  .activity-list {
    .activity-item {
      display: flex;
      align-items: center;
      padding: 8px 0;
      border-bottom: 1px solid #f0f0f0;

      &:last-child {
        border-bottom: none;
      }

      i {
        margin-right: 12px;
        font-size: 16px;
      }

      .activity-text {
        flex: 1;
        color: #606266;
      }

      .activity-time {
        color: #909399;
        font-size: 12px;
      }
    }
  }
}
</style>
