<template>
  <div class="app-container">
    <el-card>
      <div slot="header" class="clearfix">
        <span>{{ $t('resource.purchase') }}</span>
        <el-button
          style="float: right; padding: 3px 0"
          type="text"
          @click="goBack"
        >
          {{ $t('common.back') }}
        </el-button>
      </div>

      <div v-if="dataInfo">
        <!-- 数据信息展示 -->
        <el-row :gutter="20" style="margin-bottom: 30px;">
          <el-col :span="16">
            <el-card class="data-info-card">
              <div slot="header">数据信息</div>
              <el-descriptions :column="2" border>
                <el-descriptions-item label="数据ID">
                  {{ dataInfo.id }}
                </el-descriptions-item>
                <el-descriptions-item label="国家">
                  {{ dataInfo.country }}
                </el-descriptions-item>
                <el-descriptions-item label="时效性">
                  <el-tag :type="getValidityTagType(dataInfo.validity)">
                    {{ getValidityText(dataInfo.validity) }}
                  </el-tag>
                </el-descriptions-item>
                <el-descriptions-item label="数据来源">
                  {{ dataInfo.source }}
                </el-descriptions-item>
                <el-descriptions-item label="可购买数量">
                  {{ formatNumber(dataInfo.availableQuantity) }}
                </el-descriptions-item>
                <el-descriptions-item label="单价">
                  <span class="price-highlight">{{ actualPrice }} U/条</span>
                </el-descriptions-item>
                <el-descriptions-item label="运营商分布" :span="2">
                  <div class="operator-distribution">
                    <el-tag
                      v-for="operator in dataInfo.operators"
                      :key="operator.name"
                      class="operator-tag"
                    >
                      {{ operator.name }}: {{ formatNumber(operator.count) }}
                    </el-tag>
                  </div>
                </el-descriptions-item>
              </el-descriptions>
            </el-card>
          </el-col>
          <el-col :span="8">
            <el-card class="balance-info-card">
              <div slot="header">账户信息</div>
              <div class="balance-info">
                <div class="balance-item">
                  <span class="balance-label">当前余额:</span>
                  <span class="balance-value">{{ userBalance }} U</span>
                </div>
                <div class="balance-item">
                  <span class="balance-label">预估费用:</span>
                  <span class="estimated-cost">{{ estimatedCost }} U</span>
                </div>
                <div class="balance-item">
                  <span class="balance-label">余额充足:</span>
                  <el-tag :type="balanceStatus.type">
                    {{ balanceStatus.text }}
                  </el-tag>
                </div>
              </div>
            </el-card>
          </el-col>
        </el-row>

        <!-- 购买表单 -->
        <el-form
          ref="purchaseForm"
          :model="purchaseForm"
          :rules="rules"
          label-width="120px"
          class="purchase-form"
        >
          <el-divider content-position="left">购买设置</el-divider>

          <el-row :gutter="20">
            <el-col :span="12">
              <el-form-item :label="$t('resource.selectQuantity')" prop="quantity">
                <el-input-number
                  v-model="purchaseForm.quantity"
                  :min="1"
                  :max="dataInfo.availableQuantity"
                  style="width: 100%"
                  controls-position="right"
                  :placeholder="$t('resource.quantityRequired')"
                  @change="calculateCost"
                />
                <div class="quantity-tips">
                  最大可购买: {{ formatNumber(dataInfo.availableQuantity) }} 条
                </div>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item :label="$t('resource.deliveryEmail')" prop="email">
                <el-input
                  v-model="purchaseForm.email"
                  :placeholder="$t('resource.emailRequired')"
                />
                <div class="email-tips">
                  {{ $t('resource.autoDelivery') }}
                </div>
              </el-form-item>
            </el-col>
          </el-row>

          <el-form-item :label="$t('resource.selectOperator')" prop="operators">
            <el-checkbox-group v-model="purchaseForm.operators" @change="handleOperatorChange">
              <el-checkbox
                v-for="operator in dataInfo.operators"
                :key="operator.name"
                :label="operator.name"
                class="operator-checkbox"
              >
                <div class="operator-option">
                  <span class="operator-name">{{ operator.name }}</span>
                  <span class="operator-count">({{ formatNumber(operator.count) }}条)</span>
                </div>
              </el-checkbox>
            </el-checkbox-group>
            <div class="operator-tips">
              * 可选择多个运营商，系统将按比例分配数据
            </div>
          </el-form-item>

          <!-- 运营商数量分配 -->
          <el-form-item v-if="purchaseForm.operators.length > 0" label="数量分配">
            <div v-for="operator in selectedOperators" :key="operator.name" class="operator-allocation">
              <span class="allocation-label">{{ operator.name }}:</span>
              <el-input-number
                v-model="operator.allocated"
                :min="0"
                :max="operator.maxCount"
                size="small"
                style="width: 120px"
                @change="handleAllocationChange"
              />
              <span class="allocation-info">/ {{ formatNumber(operator.maxCount) }} 条</span>
            </div>
            <div class="allocation-summary">
              已分配总数: {{ formatNumber(totalAllocated) }} / {{ formatNumber(purchaseForm.quantity) }}
            </div>
          </el-form-item>

          <el-form-item label="购买备注" prop="remark">
            <el-input
              v-model="purchaseForm.remark"
              type="textarea"
              :rows="3"
              placeholder="可填写购买备注信息（选填）"
            />
          </el-form-item>

          <!-- 费用明细 -->
          <el-form-item label="费用明细">
            <div class="cost-summary">
              <div class="cost-item">
                <span>购买数量:</span>
                <span>{{ formatNumber(purchaseForm.quantity || 0) }} 条</span>
              </div>
              <div class="cost-item">
                <span>单价:</span>
                <span>{{ actualPrice }} U/条</span>
              </div>
              <div class="cost-item total">
                <span>{{ $t('resource.totalPrice') }}:</span>
                <span class="total-price">{{ estimatedCost }} U</span>
              </div>
            </div>
          </el-form-item>

          <!-- 操作按钮 -->
          <el-form-item>
            <el-button
              type="primary"
              :loading="purchaseLoading"
              :disabled="!canPurchase"
              @click="submitPurchase"
            >
              {{ $t('resource.confirmPurchase') }}
            </el-button>
            <el-button @click="resetForm">
              {{ $t('common.reset') }}
            </el-button>
            <el-button @click="goBack">
              {{ $t('common.cancel') }}
            </el-button>
          </el-form-item>
        </el-form>
      </div>
    </el-card>
  </div>
</template>

<script>
import i18nMixin from '@/mixins/i18n'

export default {
  name: 'ResourcePurchase',
  mixins: [i18nMixin],
  data() {
    return {
      dataInfo: null,
      userBalance: 1580.50,
      customerSalePriceRate: 1, // 客户销售价比例
      purchaseForm: {
        quantity: 1000,
        email: '',
        operators: [],
        remark: ''
      },
      selectedOperators: [],
      rules: {
        quantity: [
          { required: true, message: this.$t('resource.quantityRequired'), trigger: 'blur' },
          { type: 'number', min: 1, message: '购买数量必须大于0', trigger: 'blur' }
        ],
        email: [
          { required: true, message: this.$t('resource.emailRequired'), trigger: 'blur' },
          { type: 'email', message: '请输入正确的邮箱格式', trigger: 'blur' }
        ],
        operators: [
          { required: true, message: this.$t('resource.operatorRequired'), trigger: 'change' }
        ]
      },
      purchaseLoading: false
    }
  },
  computed: {
    // 计算根据销售价比例后的实际价格
    actualPrice() {
      if (!this.dataInfo) return '0.00'
      const finalPrice = this.dataInfo.sellPrice * this.customerSalePriceRate
      return finalPrice.toFixed(4)
    },
    estimatedCost() {
      if (!this.purchaseForm.quantity) return '0.00'
      return (parseFloat(this.actualPrice) * this.purchaseForm.quantity).toFixed(2)
    },
    balanceStatus() {
      const cost = parseFloat(this.estimatedCost)
      if (this.userBalance >= cost) {
        return { type: 'success', text: '是' }
      } else {
        return { type: 'danger', text: '否' }
      }
    },
    canPurchase() {
      return this.userBalance >= parseFloat(this.estimatedCost) &&
             this.purchaseForm.quantity > 0 &&
             this.purchaseForm.operators.length > 0 &&
             this.totalAllocated === this.purchaseForm.quantity
    },
    totalAllocated() {
      return this.selectedOperators.reduce((sum, op) => sum + (op.allocated || 0), 0)
    }
  },
  created() {
    const id = this.$route.params && this.$route.params.id
    this.loadCustomerInfo()
    this.loadUserEmail()
    this.fetchDataInfo(id)
  },
  methods: {
    // 加载客户信息（包括销售价比例和账户余额）
    loadCustomerInfo() {
      const currentUser = localStorage.getItem('currentUser')
      if (currentUser) {
        try {
          const userData = JSON.parse(currentUser)
          if (userData.type === 'customer') {
            const savedUsers = localStorage.getItem('userList')
            if (savedUsers) {
              const users = JSON.parse(savedUsers)
              const customer = users.find(u => u.id === userData.id)
              if (customer) {
                // 加载销售价比例
                if (customer.salePriceRate !== undefined) {
                  this.customerSalePriceRate = customer.salePriceRate
                } else {
                  this.customerSalePriceRate = 1 // 默认为1
                }

                // 加载账户余额
                if (customer.accountBalance !== undefined) {
                  this.userBalance = parseFloat(customer.accountBalance)
                }
              }
            }
          }
        } catch (e) {
          console.error('加载客户信息失败:', e)
        }
      }
    },
    // 加载用户邮箱
    loadUserEmail() {
      const currentUser = localStorage.getItem('currentUser')
      if (currentUser) {
        try {
          const userData = JSON.parse(currentUser)
          if (userData.type === 'customer' && userData.email) {
            // 如果是客户账号，使用客户邮箱作为默认发货邮箱
            this.purchaseForm.email = userData.email
          } else if (userData.type === 'customer' && userData.id) {
            // 如果当前用户信息中没有邮箱，从用户列表中查找
            const savedUsers = localStorage.getItem('userList')
            if (savedUsers) {
              const users = JSON.parse(savedUsers)
              const customer = users.find(u => u.id === userData.id)
              if (customer && customer.email) {
                this.purchaseForm.email = customer.email
              }
            }
          }
        } catch (e) {
          console.error('加载用户邮箱失败:', e)
        }
      }
    },
    fetchDataInfo(id) {
      // 模拟获取数据信息
      this.dataInfo = {
        id: id,
        country: '孟加拉国',
        validity: '3',
        source: 'Grameenphone官方',
        availableQuantity: 500000,
        operators: [
          { name: 'Grameenphone', count: 150000 },
          { name: 'Robi', count: 150000 },
          { name: 'Banglalink', count: 100000 },
          { name: 'Teletalk', count: 100000 }
        ],
        sellPrice: 0.05
      }
    },
    calculateCost() {
      // 成本计算已在computed中处理
    },
    handleOperatorChange(selected) {
      this.selectedOperators = this.dataInfo.operators
        .filter(op => selected.includes(op.name))
        .map(op => ({
          name: op.name,
          maxCount: Math.min(op.count, this.purchaseForm.quantity),
          allocated: 0
        }))

      // 自动平均分配
      this.autoAllocate()
    },
    autoAllocate() {
      if (this.selectedOperators.length === 0) return

      const avgAllocation = Math.floor(this.purchaseForm.quantity / this.selectedOperators.length)
      let remaining = this.purchaseForm.quantity

      this.selectedOperators.forEach((op, index) => {
        if (index === this.selectedOperators.length - 1) {
          op.allocated = remaining
        } else {
          const allocation = Math.min(avgAllocation, op.maxCount)
          op.allocated = allocation
          remaining -= allocation
        }
      })
    },
    handleAllocationChange() {
      // 分配变更处理
    },
    submitPurchase() {
      this.$refs.purchaseForm.validate((valid) => {
        if (valid) {
          if (this.totalAllocated !== this.purchaseForm.quantity) {
            this.$message.error('运营商数量分配总数必须等于购买数量')
            return
          }

          this.$confirm(
            `确认购买 ${this.formatNumber(this.purchaseForm.quantity)} 条数据，费用 ${this.estimatedCost} U？`,
            this.$t('common.warning'),
            {
              confirmButtonText: this.$t('common.confirm'),
              cancelButtonText: this.$t('common.cancel'),
              type: 'warning'
            }
          ).then(() => {
            this.purchaseLoading = true

            try {
              // 1. 扣除用户账户余额
              this.deductUserBalance()

              // 2. 生成购买订单
              this.createPurchaseOrder()

              // 3. 生成扣款记录
              this.createDeductRecord()

              setTimeout(() => {
                this.$message.success(this.$t('resource.purchaseSuccess'))
                this.purchaseLoading = false
                this.$router.push('/order/list')
              }, 1500)
            } catch (error) {
              this.$message.error('购买失败：' + error.message)
              this.purchaseLoading = false
            }
          }).catch(() => {})
        }
      })
    },

    // 扣除用户账户余额
    deductUserBalance() {
      const currentUser = JSON.parse(localStorage.getItem('currentUser'))
      const deductAmount = parseFloat(this.estimatedCost)

      if (currentUser && currentUser.type === 'customer') {
        const savedUsers = localStorage.getItem('userList')
        if (savedUsers) {
          const users = JSON.parse(savedUsers)
          const userIndex = users.findIndex(u => u.id === currentUser.id)

          if (userIndex !== -1) {
            const currentBalance = parseFloat(users[userIndex].accountBalance || 0)

            // 检查余额是否充足
            if (currentBalance < deductAmount) {
              throw new Error('账户余额不足')
            }

            // 扣除余额
            users[userIndex].accountBalance = (currentBalance - deductAmount).toFixed(5)
            localStorage.setItem('userList', JSON.stringify(users))

            // 更新当前显示的余额
            this.userBalance = parseFloat(users[userIndex].accountBalance)
          } else {
            throw new Error('用户信息不存在')
          }
        } else {
          throw new Error('无法获取用户数据')
        }
      } else {
        throw new Error('无效的用户类型')
      }
    },

    // 生成购买订单
    createPurchaseOrder() {
      const currentUser = JSON.parse(localStorage.getItem('currentUser'))
      const savedOrders = localStorage.getItem('orderList')
      let orders = []
      let newOrderId = 1

      if (savedOrders) {
        try {
          orders = JSON.parse(savedOrders)
          const maxId = orders.reduce((max, order) => Math.max(max, order.id || 0), 0)
          newOrderId = maxId + 1
        } catch (e) {
          console.error('解析订单数据失败:', e)
        }
      }

      // 生成订单号
      const orderNo = 'ORD' + Date.now() + Math.random().toString(36).substr(2, 4).toUpperCase()

      const newOrder = {
        id: newOrderId,
        orderNo: orderNo,
        customerId: currentUser.id,
        customerName: currentUser.customerName || currentUser.username,
        dataId: this.dataInfo.id,
        country: this.dataInfo.country,
        validity: this.dataInfo.validity,
        source: this.dataInfo.source,
        quantity: this.purchaseForm.quantity,
        unitPrice: parseFloat(this.actualPrice),
        totalAmount: parseFloat(this.estimatedCost),
        deliveryEmail: this.purchaseForm.email,
        operators: this.selectedOperators.map(op => ({
          name: op.name,
          count: op.allocated // 使用count而不是quantity，与订单列表保持一致
        })),
        status: 'pending', // pending: 待处理, processing: 处理中, completed: 已完成, failed: 失败
        remark: this.purchaseForm.remark,
        createTime: new Date().getTime(),
        deliveryTime: null
      }

      orders.push(newOrder)
      localStorage.setItem('orderList', JSON.stringify(orders))
    },

    // 生成扣款记录
    createDeductRecord() {
      const currentUser = JSON.parse(localStorage.getItem('currentUser'))
      const savedRecords = localStorage.getItem('rechargeRecords')
      let records = []
      let newRecordId = 1

      if (savedRecords) {
        try {
          records = JSON.parse(savedRecords)
          const maxId = records.reduce((max, record) => Math.max(max, record.id || 0), 0)
          newRecordId = maxId + 1
        } catch (e) {
          console.error('解析充值记录失败:', e)
        }
      }

      const deductRecord = {
        id: newRecordId,
        customerId: currentUser.id,
        customerName: currentUser.customerName || currentUser.username,
        type: 'customer',
        amount: '-' + parseFloat(this.estimatedCost).toFixed(5), // 负数表示扣款
        method: 'purchase', // 购买扣款
        status: 'success',
        createTime: new Date().getTime(),
        remark: `购买数据扣款 - ${this.dataInfo.country} ${this.formatNumber(this.purchaseForm.quantity)}条`
      }

      records.push(deductRecord)
      localStorage.setItem('rechargeRecords', JSON.stringify(records))
    },
    resetForm() {
      this.$refs.purchaseForm.resetFields()
      this.selectedOperators = []
    },
    goBack() {
      this.$router.go(-1)
    },
    formatNumber(num) {
      return num.toLocaleString()
    },
    getValidityText(validity) {
      const validityMap = {
        '3': '3天内',
        '30': '30天内',
        '30+': '30天以上'
      }
      return validityMap[validity] || validity
    },
    getValidityTagType(validity) {
      const tagMap = {
        '3': 'danger',
        '30': 'warning',
        '30+': 'success'
      }
      return tagMap[validity]
    }
  }
}
</script>

<style lang="scss" scoped>
.purchase-form {
  max-width: 800px;
  margin: 0 auto;
}

.data-info-card, .balance-info-card {
  height: 100%;
}

.operator-distribution {
  .operator-tag {
    margin-right: 10px;
    margin-bottom: 5px;
  }
}

.balance-info {
  .balance-item {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 15px;

    .balance-label {
      font-weight: bold;
      color: #606266;
    }

    .balance-value {
      color: #67c23a;
      font-weight: bold;
      font-size: 16px;
    }

    .estimated-cost {
      color: #f56c6c;
      font-weight: bold;
      font-size: 16px;
    }
  }
}

.price-highlight {
  color: #f56c6c;
  font-weight: bold;
}

.quantity-tips, .email-tips, .operator-tips {
  font-size: 12px;
  color: #909399;
  margin-top: 5px;
}

.operator-checkbox {
  display: block;
  margin-bottom: 10px;

  .operator-option {
    .operator-name {
      font-weight: bold;
    }

    .operator-count {
      color: #909399;
      margin-left: 5px;
    }
  }
}

.operator-allocation {
  display: flex;
  align-items: center;
  margin-bottom: 10px;

  .allocation-label {
    width: 120px;
    font-weight: bold;
  }

  .allocation-info {
    margin-left: 10px;
    color: #909399;
    font-size: 12px;
  }
}

.allocation-summary {
  font-weight: bold;
  color: #409eff;
  margin-top: 10px;
}

.cost-summary {
  background: #f5f7fa;
  padding: 15px;
  border-radius: 4px;

  .cost-item {
    display: flex;
    justify-content: space-between;
    margin-bottom: 10px;

    &.total {
      border-top: 1px solid #ddd;
      padding-top: 10px;
      font-weight: bold;

      .total-price {
        color: #f56c6c;
        font-size: 18px;
      }
    }
  }
}
</style>
