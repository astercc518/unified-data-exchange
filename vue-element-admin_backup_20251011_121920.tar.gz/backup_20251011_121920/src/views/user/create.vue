<template>
  <div class="app-container">
    <el-card>
      <div slot="header" class="clearfix">
        <span>{{ $t('user.create') }}</span>
        <el-button
          style="float: right; padding: 3px 0"
          type="text"
          @click="goBack"
        >
          {{ $t('common.back') }}
        </el-button>
      </div>

      <el-form
        ref="userForm"
        :model="userForm"
        :rules="rules"
        label-width="120px"
        class="user-form"
      >
        <!-- 基本信息 -->
        <el-divider content-position="left">{{ $t('user.basicInfo') }}</el-divider>

        <el-row :gutter="20">
          <el-col :span="12">
            <el-form-item :label="$t('user.agentName')" prop="agentId">
              <el-select
                v-model="userForm.agentId"
                :placeholder="$t('user.pleaseSelectAgent')"
                style="width: 100%"
                filterable
              >
                <el-option
                  v-for="agent in agentOptions"
                  :key="agent.value"
                  :label="agent.label"
                  :value="agent.value"
                />
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item :label="$t('user.customerName')" prop="customerName">
              <el-input
                v-model="userForm.customerName"
                :placeholder="$t('user.pleaseEnterCustomerName')"
              />
            </el-form-item>
          </el-col>
        </el-row>

        <el-row :gutter="20">
          <el-col :span="12">
            <el-form-item :label="$t('user.loginAccount')" prop="loginAccount">
              <el-input
                v-model="userForm.loginAccount"
                :placeholder="$t('user.pleaseEnterLoginAccount')"
              />
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item :label="$t('user.loginPassword')" prop="loginPassword">
              <el-input
                v-model="userForm.loginPassword"
                type="password"
                :placeholder="$t('user.pleaseEnterLoginPassword')"
                show-password
              />
            </el-form-item>
          </el-col>
        </el-row>

        <el-row :gutter="20">
          <el-col :span="12">
            <el-form-item :label="$t('user.salePriceRate')" prop="salePriceRate">
              <el-input-number
                v-model="userForm.salePriceRate"
                :placeholder="$t('user.pleaseEnterSalePriceRate')"
                :precision="2"
                :min="0"
                :step="0.1"
                style="width: 100%"
              />
              <div class="field-note">{{ $t('user.salePriceRateNote') }}</div>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item :label="$t('user.email')" prop="email">
              <el-input
                v-model="userForm.email"
                :placeholder="$t('user.pleaseEnterEmail')"
              />
            </el-form-item>
          </el-col>
        </el-row>

        <!-- 账户信息 -->
        <el-divider content-position="left">{{ $t('user.accountInfo') }}</el-divider>

        <el-row :gutter="20">
          <el-col :span="12">
            <el-form-item :label="$t('user.accountBalance')" prop="accountBalance">
              <el-input-number
                v-model="userForm.accountBalance"
                :placeholder="$t('user.accountBalance')"
                :precision="5"
                :min="0"
                :step="1"
                style="width: 100%"
              />
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item :label="$t('user.overdraftAmount')" prop="overdraftAmount">
              <el-input-number
                v-model="userForm.overdraftAmount"
                :placeholder="$t('user.overdraftAmount')"
                :precision="5"
                :min="0"
                :step="1"
                style="width: 100%"
              />
            </el-form-item>
          </el-col>
        </el-row>

        <!-- 其他信息 -->
        <el-divider content-position="left">{{ $t('user.contactInfo') }}</el-divider>

        <el-row :gutter="20">
          <el-col :span="12">
            <el-form-item :label="$t('user.status')" prop="status">
              <el-radio-group v-model="userForm.status">
                <el-radio :label="1">{{ $t('user.active') }}</el-radio>
                <el-radio :label="0">{{ $t('user.inactive') }}</el-radio>
              </el-radio-group>
            </el-form-item>
          </el-col>
        </el-row>

        <el-form-item :label="$t('user.remark')" prop="remark">
          <el-input
            v-model="userForm.remark"
            :placeholder="$t('user.remark')"
            type="textarea"
            :rows="3"
          />
        </el-form-item>

        <!-- 操作按钮 -->
        <el-form-item>
          <el-button
            type="primary"
            :loading="submitLoading"
            @click="submitForm"
          >
            {{ $t('common.save') }}
          </el-button>
          <el-button @click="resetForm">
            {{ $t('common.reset') }}
          </el-button>
          <el-button @click="goBack">
            {{ $t('common.cancel') }}
          </el-button>
        </el-form-item>
      </el-form>
    </el-card>
  </div>
</template>

<script>
import i18nMixin from '@/mixins/i18n'

export default {
  name: 'CreateUser',
  mixins: [i18nMixin],
  data() {
    // 登录账号验证
    const validateLoginAccount = (rule, value, callback) => {
      if (!value) {
        callback(new Error(this.$t('user.pleaseEnterLoginAccount')))
      } else if (value.length < 3) {
        callback(new Error('登录账号至少3个字符'))
      } else {
        callback()
      }
    }

    // 密码验证
    const validatePassword = (rule, value, callback) => {
      if (!value) {
        callback(new Error(this.$t('user.pleaseEnterLoginPassword')))
      } else if (value.length < 6) {
        callback(new Error('密码至少6个字符'))
      } else {
        callback()
      }
    }

    // 邮箱验证
    const validateEmail = (rule, value, callback) => {
      if (!value) {
        callback(new Error(this.$t('user.pleaseEnterEmail')))
      } else {
        const emailReg = /^[a-zA-Z0-9_-]+@[a-zA-Z0-9_-]+(\.[a-zA-Z0-9_-]+)+$/
        if (!emailReg.test(value)) {
          callback(new Error(this.$t('user.invalidEmail')))
        } else {
          callback()
        }
      }
    }

    return {
      userForm: {
        agentId: '',
        customerName: '',
        loginAccount: '',
        loginPassword: '',
        salePriceRate: 1,
        accountBalance: 0,
        overdraftAmount: 0,
        email: '',
        status: 1,
        remark: ''
      },
      agentOptions: [],
      rules: {
        agentId: [{ required: true, message: this.$t('user.pleaseSelectAgent'), trigger: 'change' }],
        customerName: [{ required: true, message: this.$t('user.pleaseEnterCustomerName'), trigger: 'blur' }],
        loginAccount: [{ required: true, validator: validateLoginAccount, trigger: 'blur' }],
        loginPassword: [{ required: true, validator: validatePassword, trigger: 'blur' }],
        salePriceRate: [{ required: false, message: this.$t('user.pleaseEnterSalePriceRate'), trigger: 'blur' }],
        email: [{ required: true, validator: validateEmail, trigger: 'blur' }]
      },
      submitLoading: false
    }
  },
  created() {
    this.loadAgents()
  },
  methods: {
    // 加载代理列表
    loadAgents() {
      const savedAgents = localStorage.getItem('agentList')
      if (savedAgents) {
        try {
          const agents = JSON.parse(savedAgents)
          // 只显示激活状态的代理
          this.agentOptions = agents
            .filter(agent => agent.status === 1)
            .map(agent => ({
              value: String(agent.id),
              label: agent.agentName
            }))
        } catch (e) {
          console.error('加载代理数据失败:', e)
          this.agentOptions = []
        }
      } else {
        this.agentOptions = []
      }
    },
    submitForm() {
      this.$refs.userForm.validate((valid) => {
        if (valid) {
          this.submitLoading = true

          // 从localStorage获取现有用户列表
          const savedUsers = localStorage.getItem('userList')
          let users = []
          let newId = 1

          if (savedUsers) {
            try {
              users = JSON.parse(savedUsers)
              // 获取最大ID
              const maxId = users.reduce((max, user) => Math.max(max, user.id || 0), 0)
              newId = maxId + 1
            } catch (e) {
              console.error('解析用户数据失败:', e)
            }
          }

          // 查找代理名称
          const selectedAgent = this.agentOptions.find(agent => agent.value === this.userForm.agentId)
          const agentName = selectedAgent ? selectedAgent.label : ''

          // 创建新用户对象
          const newUser = {
            id: newId,
            loginAccount: this.userForm.loginAccount,
            loginPassword: this.userForm.loginPassword,
            customerName: this.userForm.customerName,
            email: this.userForm.email,
            agentId: this.userForm.agentId,
            agentName: agentName,
            salePriceRate: this.userForm.salePriceRate,
            accountBalance: this.userForm.accountBalance,
            overdraftAmount: this.userForm.overdraftAmount,
            status: this.userForm.status,
            createTime: new Date().getTime(),
            remark: this.userForm.remark
          }

          // 添加到用户列表
          users.push(newUser)

          // 保存到localStorage
          localStorage.setItem('userList', JSON.stringify(users))

          // 如果账户金额大于0，添加一条初始充值记录
          if (this.userForm.accountBalance > 0) {
            const savedRechargeRecords = localStorage.getItem('rechargeRecords')
            let rechargeRecords = []
            let newRechargeId = 1

            if (savedRechargeRecords) {
              try {
                rechargeRecords = JSON.parse(savedRechargeRecords)
                const maxId = rechargeRecords.reduce((max, record) => Math.max(max, record.id || 0), 0)
                newRechargeId = maxId + 1
              } catch (e) {
                console.error('解析充值记录失败:', e)
              }
            }

            // 创建初始充值记录
            const initialRecharge = {
              id: newRechargeId,
              customerId: newId,
              customerName: this.userForm.customerName,
              type: 'customer',
              amount: parseFloat(this.userForm.accountBalance).toFixed(5),
              method: 'initial',
              status: 'success',
              createTime: new Date().getTime(),
              remark: '创建账户初始金额'
            }

            rechargeRecords.push(initialRecharge)
            localStorage.setItem('rechargeRecords', JSON.stringify(rechargeRecords))
          }

          // 更新所属代理的绑定用户数
          if (this.userForm.agentId) {
            const savedAgents = localStorage.getItem('agentList')
            if (savedAgents) {
              try {
                const agents = JSON.parse(savedAgents)
                const agent = agents.find(a => String(a.id) === String(this.userForm.agentId))
                if (agent) {
                  // 计算该代理的绑定用户数
                  const bindUsersCount = users.filter(u => String(u.agentId) === String(agent.id)).length
                  agent.bindUsers = bindUsersCount
                  localStorage.setItem('agentList', JSON.stringify(agents))
                }
              } catch (e) {
                console.error('更新代理绑定用户数失败:', e)
              }
            }
          }

          console.log('创建用户数据:', newUser)

          setTimeout(() => {
            this.$message({
              type: 'success',
              message: this.$t('user.createSuccess')
            })
            this.submitLoading = false
            this.$router.push('/user/customer-list')
          }, 800)
        } else {
          return false
        }
      })
    },
    resetForm() {
      this.$refs.userForm.resetFields()
    },
    goBack() {
      this.$router.go(-1)
    }
  }
}
</script>

<style lang="scss" scoped>
.user-form {
  max-width: 900px;
  margin: 0 auto;
}

.field-note {
  font-size: 12px;
  color: #909399;
  margin-top: 5px;
}
</style>
