<template>
  <div class="app-container">
    <el-card>
      <div slot="header" class="clearfix">
        <span>{{ $t('data.upload') }}</span>
      </div>

      <el-form
        ref="uploadForm"
        :model="uploadForm"
        :rules="rules"
        label-width="120px"
        class="upload-form"
      >
        <!-- 基本信息 -->
        <el-divider content-position="left">{{ $t('user.basicInfo') }}</el-divider>

        <el-row :gutter="20">
          <el-col :span="8">
            <el-form-item :label="$t('data.country')" prop="country">
              <el-select
                v-model="uploadForm.country"
                :placeholder="$t('data.selectCountry')"
                filterable
                remote
                reserve-keyword
                :remote-method="searchCountries"
                :loading="countryLoading"
                clearable
                style="width: 100%"
                @focus="initCountryOptions"
              >
                <el-option-group
                  v-if="showPopularCountries"
                  label="热门国家"
                >
                  <el-option
                    v-for="country in popularCountries"
                    :key="country.code"
                    :label="`${country.name} (${country.nameEn}) [${country.code}]`"
                    :value="country.code"
                  >
                    <span style="float: left">{{ country.name }} ({{ country.nameEn }})</span>
                    <span style="float: right; color: #8492a6; font-size: 13px">{{ country.code }}</span>
                  </el-option>
                </el-option-group>
                <el-option-group
                  v-for="(countries, region) in groupedCountries"
                  :key="region"
                  :label="getRegionName(region)"
                >
                  <el-option
                    v-for="country in countries"
                    :key="country.code"
                    :label="`${country.name} (${country.nameEn}) [${country.code}]`"
                    :value="country.code"
                  >
                    <span style="float: left">{{ country.name }} ({{ country.nameEn }})</span>
                    <span style="float: right; color: #8492a6; font-size: 13px">{{ country.code }}</span>
                  </el-option>
                </el-option-group>
                <el-option
                  v-for="country in filteredCountries"
                  :key="country.code"
                  :label="`${country.name} (${country.nameEn}) [${country.code}]`"
                  :value="country.code"
                >
                  <span style="float: left">{{ country.name }} ({{ country.nameEn }})</span>
                  <span style="float: right; color: #8492a6; font-size: 13px">{{ country.code }}</span>
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item :label="$t('data.dataType')" prop="dataType">
              <el-input
                v-model="uploadForm.dataType"
                :placeholder="$t('data.selectDataType')"
                style="width: 100%"
              />
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item :label="$t('data.source')" prop="source">
              <el-input
                v-model="uploadForm.source"
                :placeholder="$t('data.enterSource')"
              />
            </el-form-item>
          </el-col>
        </el-row>

        <el-row :gutter="20">
          <el-col :span="8">
            <el-form-item :label="$t('data.validity')" prop="validity">
              <el-select
                v-model="uploadForm.validity"
                :placeholder="$t('data.selectValidity')"
                style="width: 100%"
              >
                <el-option
                  :label="$t('data.validityDay3')"
                  value="3"
                />
                <el-option
                  :label="$t('data.validityDay30')"
                  value="30"
                />
                <el-option
                  :label="$t('data.validityOver30')"
                  value="30+"
                />
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item :label="$t('data.costPrice')" prop="costPrice">
              <el-input-number
                v-model="uploadForm.costPrice"
                :min="0"
                :precision="4"
                style="width: 100%"
                controls-position="right"
                :placeholder="$t('data.enterCostPrice')"
              />
              <span style="margin-left: 10px;">U/条</span>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item :label="$t('data.sellPrice')" prop="sellPrice">
              <el-input-number
                v-model="uploadForm.sellPrice"
                :min="0"
                :precision="4"
                style="width: 100%"
                controls-position="right"
                :placeholder="$t('data.enterSellPrice')"
              />
              <span style="margin-left: 10px;">U/条</span>
            </el-form-item>
          </el-col>
        </el-row>

        <el-row :gutter="20">
          <el-col :span="24">
            <el-form-item :label="$t('data.remark')" prop="remark">
              <el-input
                v-model="uploadForm.remark"
                type="textarea"
                :rows="3"
                :placeholder="$t('data.enterRemark')"
                :maxlength="500"
                show-word-limit
              />
            </el-form-item>
          </el-col>
        </el-row>

        <el-row :gutter="20">
          <el-col :span="12">
            <el-form-item label="利润率">
              <el-input
                :value="profitRate"
                disabled
                style="width: 100%"
              >
                <template slot="append">%</template>
              </el-input>
            </el-form-item>
          </el-col>
        </el-row>

        <!-- 文件上传 -->
        <el-divider content-position="left">{{ $t('data.uploadFile') }}</el-divider>

        <el-form-item :label="$t('data.dataFormat')" prop="file">
          <el-upload
            ref="upload"
            class="upload-demo"
            drag
            action=""
            :on-change="handleFileChange"
            :before-upload="beforeUpload"
            :auto-upload="false"
            :limit="1"
            accept=".txt"
          >
            <i class="el-icon-upload" />
            <div class="el-upload__text">
              将文件拖到此处，或<em>点击上传</em>
            </div>
            <div slot="tip" class="el-upload__tip">
              {{ $t('data.txtFormat') }}，文件大小不超过100MB
            </div>
          </el-upload>
        </el-form-item>

        <!-- 文件预览信息 -->
        <el-form-item v-if="fileInfo.name" label="文件信息">
          <el-descriptions :column="2" border>
            <el-descriptions-item label="文件名">
              {{ fileInfo.name }}
            </el-descriptions-item>
            <el-descriptions-item label="文件大小">
              {{ formatFileSize(fileInfo.size) }}
            </el-descriptions-item>
            <el-descriptions-item label="预估行数">
              {{ fileInfo.lines || '计算中...' }}
            </el-descriptions-item>
            <el-descriptions-item label="上传时间">
              {{ fileInfo.uploadTime }}
            </el-descriptions-item>
          </el-descriptions>
        </el-form-item>

        <!-- 操作按钮 -->
        <el-form-item>
          <el-button
            type="primary"
            :loading="uploadLoading"
            :disabled="!fileInfo.name"
            @click="submitUpload"
          >
            {{ $t('data.upload') }}
          </el-button>
          <el-button @click="resetForm">
            {{ $t('common.reset') }}
          </el-button>
        </el-form-item>
      </el-form>
    </el-card>

    <!-- 最近上传记录 -->
    <el-card style="margin-top: 20px;">
      <div slot="header" class="clearfix">
        <span>最近上传记录</span>
      </div>

      <el-table
        :data="recentUploads"
        border
        style="width: 100%"
      >
        <el-table-column
          label="文件名"
          prop="fileName"
          min-width="150"
        />
        <el-table-column
          label="国家"
          prop="country"
          width="120"
        />
        <el-table-column
          label="数据类型"
          prop="dataType"
          width="100"
        />
        <el-table-column
          label="时效"
          prop="validity"
          width="100"
        />
        <el-table-column
          label="数据来源"
          prop="source"
          width="120"
        />
        <el-table-column
          label="数量"
          prop="quantity"
          width="100"
        >
          <template slot-scope="{row}">
            {{ formatNumber(row.quantity) }}
          </template>
        </el-table-column>
        <el-table-column
          label="销售价(U)"
          prop="sellPrice"
          width="100"
        />
        <el-table-column
          label="成本价(U)"
          prop="costPrice"
          width="100"
        />
        <el-table-column
          label="备注"
          prop="remark"
          min-width="150"
          show-overflow-tooltip
        />
        <el-table-column
          label="上传时间"
          prop="uploadTime"
          width="160"
        >
          <template slot-scope="{row}">
            {{ row.uploadTime | parseTime('{y}-{m}-{d} {h}:{i}') }}
          </template>
        </el-table-column>
        <el-table-column
          label="状态"
          prop="status"
          width="100"
        >
          <template slot-scope="{row}">
            <el-tag :type="getStatusType(row.status)">
              {{ getStatusText(row.status) }}
            </el-tag>
          </template>
        </el-table-column>
      </el-table>
    </el-card>
  </div>
</template>

<script>
import { parseTime } from '@/utils'
import i18nMixin from '@/mixins/i18n'
import {
  filterCountries,
  getCountryByCode,
  getPopularCountries
} from '@/data/countries'
import { distributeQuantityByOperators } from '@/data/operators'

export default {
  name: 'DataUpload',
  filters: {
    parseTime
  },
  mixins: [i18nMixin],
  data() {
    return {
      uploadForm: {
        country: '',
        dataType: '',
        validity: '',
        source: '',
        sellPrice: 0.05,
        costPrice: 0.02,
        remark: '',
        file: null
      },
      fileInfo: {
        name: '',
        size: 0,
        lines: 0,
        uploadTime: ''
      },
      rules: {
        country: [{ required: true, message: this.$t('data.selectCountry'), trigger: 'change' }],
        dataType: [{ required: true, message: this.$t('data.selectDataType'), trigger: 'blur' }],
        validity: [{ required: true, message: this.$t('data.selectValidity'), trigger: 'change' }],
        source: [{ required: true, message: this.$t('data.enterSource'), trigger: 'blur' }],
        sellPrice: [{ required: true, message: this.$t('data.enterSellPrice'), trigger: 'blur' }],
        costPrice: [{ required: true, message: this.$t('data.enterCostPrice'), trigger: 'blur' }]
      },
      uploadLoading: false,
      recentUploads: [],
      // 国家相关数据
      countryLoading: false,
      filteredCountries: [],
      popularCountries: [],
      groupedCountries: {},
      showPopularCountries: true,
      countrySearchKeyword: ''
    }
  },
  computed: {
    profitRate() {
      if (this.uploadForm.costPrice <= 0) return '0.00'
      const rate = ((this.uploadForm.sellPrice - this.uploadForm.costPrice) / this.uploadForm.costPrice * 100)
      return rate.toFixed(2)
    }
  },
  created() {
    this.getRecentUploads()
    this.initCountryData()
  },
  methods: {
    handleFileChange(file) {
      this.fileInfo = {
        name: file.name,
        size: file.size,
        uploadTime: new Date().toLocaleString(),
        lines: 0
      }

      // 实际读取文件内容计算行数
      this.calculateFileLines(file.raw)

      this.uploadForm.file = file.raw
    },
    beforeUpload(file) {
      const isTxt = file.type === 'text/plain' || file.name.endsWith('.txt')
      const isLt100M = file.size / 1024 / 1024 < 100

      if (!isTxt) {
        this.$message.error('只能上传 TXT 格式的文件!')
        return false
      }
      if (!isLt100M) {
        this.$message.error('上传文件大小不能超过 100MB!')
        return false
      }
      return false // 阻止自动上传
    },

    // 实际计算文件行数
    calculateFileLines(file) {
      if (file && file.size > 0) {
        const reader = new FileReader()
        reader.onload = (e) => {
          try {
            const text = e.target.result
            // 计算实际行数（非空行）
            const lines = text.split('\n').filter(line => line.trim().length > 0)
            this.fileInfo.lines = lines.length

            console.log(`✅ 文件行数计算完成: ${lines.length} 行`)

            // 如果文件太大，只读取前面部分进行估算
            if (file.size > 10 * 1024 * 1024) { // 10MB以上的文件
              const sampleLines = lines.length
              const sampleSize = text.length
              const estimatedLines = Math.round((file.size / sampleSize) * sampleLines)
              this.fileInfo.lines = estimatedLines
              console.log(`ℹ️ 大文件估算行数: ${estimatedLines} 行`)
            }
          } catch (error) {
            console.error('读取文件失败:', error)
            // 如果读取失败，使用文件大小估算
            this.fileInfo.lines = Math.floor(file.size / 50) // 假设平均每行50字节
          }
        }

        reader.onerror = () => {
          console.error('文件读取错误')
          // 使用文件大小估算
          this.fileInfo.lines = Math.floor(file.size / 50)
        }

        // 对于大文件，只读取前1MB进行采样
        if (file.size > 10 * 1024 * 1024) {
          const blob = file.slice(0, 1024 * 1024) // 读取前1MB
          reader.readAsText(blob, 'utf-8')
        } else {
          reader.readAsText(file, 'utf-8')
        }
      } else {
        this.fileInfo.lines = 0
      }
    },
    submitUpload() {
      this.$refs.uploadForm.validate((valid) => {
        if (valid && this.uploadForm.file) {
          this.uploadLoading = true

          // 模拟上传过程
          setTimeout(() => {
            this.$message.success(this.$t('data.uploadSuccess'))
            this.uploadLoading = false

            // 创建上传记录
            const uploadRecord = {
              fileName: this.fileInfo.name,
              country: this.getSelectedCountryName(),
              countryCode: this.uploadForm.country,
              dataType: this.getDataTypeText(this.uploadForm.dataType),
              validity: this.getValidityText(this.uploadForm.validity),
              validityCode: this.uploadForm.validity,
              source: this.uploadForm.source,
              quantity: this.fileInfo.lines,
              sellPrice: this.uploadForm.sellPrice,
              costPrice: this.uploadForm.costPrice,
              remark: this.uploadForm.remark,
              uploadTime: new Date(),
              status: 'success'
            }

            // 添加到最近上传记录
            this.recentUploads.unshift(uploadRecord)

            // 保存到localStorage用于资源中心展示
            this.saveToResourceCenter(uploadRecord)

            this.resetForm()
          }, 3000)
        } else {
          this.$message.error(this.$t('data.fileRequired'))
        }
      })
    },
    resetForm() {
      this.$refs.uploadForm.resetFields()
      this.$refs.upload.clearFiles()
      this.fileInfo = {
        name: '',
        size: 0,
        lines: 0,
        uploadTime: ''
      }
    },
    getRecentUploads() {
      // 模拟获取最近上传记录
      this.recentUploads = [
        {
          fileName: 'bangladesh_phones_20231201.txt',
          country: '孟加拉国',
          dataType: '手机号码',
          validity: '3天内',
          source: '移动运营商',
          quantity: 50000,
          sellPrice: 0.05,
          costPrice: 0.04,
          remark: '高质量手机号码数据，来源于官方渠道，数据准确性高',
          uploadTime: new Date('2023-12-01'),
          status: 'success'
        },
        {
          fileName: 'india_data_20231130.txt',
          country: '印度',
          dataType: '用户资料',
          validity: '30天内',
          source: '第三方采集',
          quantity: 80000,
          sellPrice: 0.04,
          costPrice: 0.03,
          remark: '包含用户姓名、年龄、地区等基本信息，适合精准营销',
          uploadTime: new Date('2023-11-30'),
          status: 'processing'
        },
        {
          fileName: 'thailand_mobile_20231129.txt',
          country: '泰国',
          dataType: '电话号码',
          validity: '30天以上',
          source: '官方数据',
          quantity: 65000,
          sellPrice: 0.06,
          costPrice: 0.045,
          remark: '可验证的有效电话号码，适合电话营销和短信推广',
          uploadTime: new Date('2023-11-29'),
          status: 'success'
        }
      ]
    },
    formatFileSize(bytes) {
      if (bytes === 0) return '0 B'
      const k = 1024
      const sizes = ['B', 'KB', 'MB', 'GB']
      const i = Math.floor(Math.log(bytes) / Math.log(k))
      return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i]
    },
    formatNumber(num) {
      return num.toLocaleString()
    },
    getCountryText(countryCode) {
      const country = getCountryByCode(countryCode)
      return country ? country.name : countryCode
    },
    getValidityText(validity) {
      const validityMap = {
        '3': '3天内',
        '30': '30天内',
        '30+': '30天以上'
      }
      return validityMap[validity] || validity
    },
    getStatusType(status) {
      const statusMap = {
        success: 'success',
        processing: 'warning',
        failed: 'danger'
      }
      return statusMap[status]
    },
    getStatusText(status) {
      const statusMap = {
        success: '成功',
        processing: '处理中',
        failed: '失败'
      }
      return statusMap[status]
    },

    // 国家相关方法
    initCountryData() {
      // 初始化热门国家
      this.popularCountries = getPopularCountries()
      // 初始化分组国家（仅在未搜索时显示）
      this.groupedCountries = {}
      this.filteredCountries = []
    },

    initCountryOptions() {
      // 焦点时初始化国家选项
      if (!this.countrySearchKeyword) {
        this.showPopularCountries = true
        this.groupedCountries = {}
        this.filteredCountries = []
      }
    },

    searchCountries(keyword) {
      this.countrySearchKeyword = keyword
      this.countryLoading = true

      // 模拟异步搜索
      setTimeout(() => {
        if (keyword) {
          this.showPopularCountries = false
          this.groupedCountries = {}
          this.filteredCountries = filterCountries(keyword)
        } else {
          this.showPopularCountries = true
          this.groupedCountries = {}
          this.filteredCountries = []
        }
        this.countryLoading = false
      }, 300)
    },

    getRegionName(region) {
      const regionMap = {
        'Asia': '亚洲',
        'Europe': '欧洲',
        'North America': '北美洲',
        'South America': '南美洲',
        'Africa': '非洲',
        'Oceania': '大洋洲'
      }
      return regionMap[region] || region
    },

    getSelectedCountryName() {
      if (!this.uploadForm.country) return ''
      const country = getCountryByCode(this.uploadForm.country)
      return country ? country.name : this.uploadForm.country
    },

    getDataTypeText(dataType) {
      // 直接返回数据类型，因为现在直接存储中文名称
      return dataType || '未知类型'
    },

    // 保存数据到资源中心
    saveToResourceCenter(uploadRecord) {
      console.log('🔄 开始保存数据到资源中心:', uploadRecord)

      try {
        // 获取现有的资源数据
        const savedDataList = localStorage.getItem('dataList')
        let dataList = []
        let newId = 1

        if (savedDataList) {
          try {
            dataList = JSON.parse(savedDataList)
            console.log('📄 现有数据条数:', dataList.length)
          } catch (parseError) {
            console.error('解析现有数据失败，使用空数组:', parseError)
            dataList = []
          }
          // 获取最大ID
          const maxId = dataList.reduce((max, item) => Math.max(max, item.id || 0), 0)
          newId = maxId + 1
          console.log('🆔 新数据ID:', newId)
        } else {
          console.log('📄 首次创建数据列表')
        }

        // 确保必要的字段存在
        if (!uploadRecord.countryCode || !uploadRecord.country) {
          console.error('❌ 关键字段缺失:', {
            countryCode: uploadRecord.countryCode,
            country: uploadRecord.country
          })
          return
        }

        // 根据国家代码获取国家信息
        const countryInfo = this.getCountryInfoByCode(uploadRecord.countryCode)
        console.log('🌍 国家信息:', countryInfo)

        // 创建资源数据项
        const resourceData = {
          id: newId,
          country: uploadRecord.country,
          countryCode: uploadRecord.countryCode,
          validity: uploadRecord.validityCode || uploadRecord.validity,
          source: uploadRecord.source,
          dataType: uploadRecord.dataType,
          availableQuantity: uploadRecord.quantity,
          operators: this.generateOperators(uploadRecord.quantity, countryInfo),
          sellPrice: uploadRecord.sellPrice,
          costPrice: uploadRecord.costPrice,
          remark: uploadRecord.remark || '',
          uploadTime: uploadRecord.uploadTime ? uploadRecord.uploadTime.getTime() : Date.now(),
          status: 'available'
        }

        console.log('📦 准备保存的数据:', resourceData)

        // 添加到数据列表
        dataList.push(resourceData)

        // 保存到localStorage
        try {
          localStorage.setItem('dataList', JSON.stringify(dataList))
          console.log('✅ 数据成功保存到localStorage，总数据量:', dataList.length)

          // 验证保存是否成功
          const verifyData = localStorage.getItem('dataList')
          if (verifyData) {
            const parsed = JSON.parse(verifyData)
            console.log('✅ 验证成功：localStorage中有', parsed.length, '条数据')

            // 检查最新的数据是否包含刚保存的
            const latestData = parsed[parsed.length - 1]
            if (latestData && latestData.id === resourceData.id) {
              console.log('✅ 最新数据验证通过:', latestData.country, latestData.dataType)
            } else {
              console.warn('⚠️ 最新数据验证失败')
            }
          } else {
            console.error('❌ 验证失败：无法从localStorage读取数据')
          }
        } catch (saveError) {
          console.error('❌ 保存到localStorage失败:', saveError)
          return
        }

        // 显示成功消息
        this.$message({
          type: 'success',
          message: `数据已保存到资源中心 (${uploadRecord.country} - ${uploadRecord.dataType})`,
          duration: 3000
        })
      } catch (error) {
        console.error('❌ 保存数据到资源中心失败:', error)
        this.$message({
          type: 'error',
          message: '保存数据到资源中心失败，请重试',
          duration: 5000
        })
      }
    },

    // 根据国家代码获取国家信息
    getCountryInfoByCode(countryCode) {
      const country = getCountryByCode(countryCode)
      return country || { code: countryCode, name: '未知国家', region: 'Unknown' }
    },

    // 生成运营商分布（使用真实市场份额数据）
    generateOperators(totalQuantity, countryInfo) {
      const countryCode = countryInfo.code

      // 使用新的运营商数据库按市场份额分配
      const distribution = distributeQuantityByOperators(totalQuantity, countryCode)

      console.log(`ℹ️ ${countryInfo.name}运营商分布:`, distribution)

      return distribution
    }
  }
}
</script>

<style lang="scss" scoped>
.upload-form {
  max-width: 800px;
  margin: 0 auto;
}

.upload-demo {
  width: 100%;
}

// 国家选择器样式优化
::v-deep .el-select-dropdown {
  .el-select-group__title {
    font-weight: bold;
    color: #409eff;
    background-color: #f5f7fa;
    border-bottom: 1px solid #e4e7ed;
  }

  .el-option {
    height: auto;
    line-height: 1.5;
    padding: 8px 20px;

    &:hover {
      background-color: #f5f7fa;
    }

    .el-option__text {
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
  }
}

// 热门国家分组样式
::v-deep .el-select-group:first-child {
  .el-select-group__title {
    color: #f56c6c;
    background-color: #fef0f0;
  }
}
</style>
