<template>
  <div class="app-container">
    <el-card>
      <div slot="header" class="clearfix">
        <span>{{ $t('data.pricing') }}</span>
      </div>

      <!-- 定价规则卡片 -->
      <el-row :gutter="20" style="margin-bottom: 20px;">
        <el-col :span="8">
          <el-card class="pricing-rule-card">
            <div slot="header">3天内数据定价</div>
            <div class="pricing-content">
              <div class="price-item">
                <span class="price-label">成本价:</span>
                <span class="price-value cost">0.04 U/条</span>
              </div>
              <div class="price-item">
                <span class="price-label">销售价:</span>
                <span class="price-value sell">0.05 U/条</span>
              </div>
              <div class="price-item">
                <span class="price-label">利润率:</span>
                <span class="price-value profit">25%</span>
              </div>
            </div>
          </el-card>
        </el-col>
        <el-col :span="8">
          <el-card class="pricing-rule-card">
            <div slot="header">30天内数据定价</div>
            <div class="pricing-content">
              <div class="price-item">
                <span class="price-label">成本价:</span>
                <span class="price-value cost">0.03 U/条</span>
              </div>
              <div class="price-item">
                <span class="price-label">销售价:</span>
                <span class="price-value sell">0.04 U/条</span>
              </div>
              <div class="price-item">
                <span class="price-label">利润率:</span>
                <span class="price-value profit">33.3%</span>
              </div>
            </div>
          </el-card>
        </el-col>
        <el-col :span="8">
          <el-card class="pricing-rule-card">
            <div slot="header">30天以上数据定价</div>
            <div class="pricing-content">
              <div class="price-item">
                <span class="price-label">成本价:</span>
                <span class="price-value cost">0.02 U/条</span>
              </div>
              <div class="price-item">
                <span class="price-label">销售价:</span>
                <span class="price-value sell">0.03 U/条</span>
              </div>
              <div class="price-item">
                <span class="price-label">利润率:</span>
                <span class="price-value profit">50%</span>
              </div>
            </div>
          </el-card>
        </el-col>
      </el-row>

      <!-- 定价管理表格 -->
      <el-table
        :data="pricingList"
        border
        style="width: 100%"
      >
        <el-table-column
          label="国家"
          prop="country"
          width="120"
        />
        <el-table-column
          label="时效性"
          prop="validity"
          width="120"
          align="center"
        >
          <template slot-scope="{row}">
            <el-tag :type="getValidityTagType(row.validity)">
              {{ getValidityText(row.validity) }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column
          label="当前成本价(U/条)"
          prop="costPrice"
          width="150"
          align="center"
        >
          <template slot-scope="{row}">
            <el-input-number
              v-model="row.costPrice"
              :precision="4"
              :step="0.001"
              :min="0"
              size="mini"
              style="width: 120px"
              @change="handlePriceChange(row)"
            />
          </template>
        </el-table-column>
        <el-table-column
          label="当前销售价(U/条)"
          prop="sellPrice"
          width="150"
          align="center"
        >
          <template slot-scope="{row}">
            <el-input-number
              v-model="row.sellPrice"
              :precision="4"
              :step="0.001"
              :min="0"
              size="mini"
              style="width: 120px"
              @change="handlePriceChange(row)"
            />
          </template>
        </el-table-column>
        <el-table-column
          label="利润率"
          width="100"
          align="center"
        >
          <template slot-scope="{row}">
            <span :class="getProfitClass(row.profitRate)">
              {{ row.profitRate }}%
            </span>
          </template>
        </el-table-column>
        <el-table-column
          label="适用数据量"
          prop="dataCount"
          width="120"
          align="center"
        >
          <template slot-scope="{row}">
            {{ formatNumber(row.dataCount) }}
          </template>
        </el-table-column>
        <el-table-column
          label="预估收益(U)"
          width="120"
          align="center"
        >
          <template slot-scope="{row}">
            {{ ((row.sellPrice - row.costPrice) * row.dataCount).toFixed(2) }}
          </template>
        </el-table-column>
        <el-table-column
          label="最后更新时间"
          prop="updateTime"
          width="160"
          align="center"
        >
          <template slot-scope="{row}">
            {{ row.updateTime | parseTime('{y}-{m}-{d} {h}:{i}') }}
          </template>
        </el-table-column>
        <el-table-column
          label="操作"
          align="center"
          width="120"
        >
          <template slot-scope="{row}">
            <el-button
              type="primary"
              size="mini"
              :loading="row.saving"
              @click="savePricing(row)"
            >
              保存
            </el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <!-- 历史定价记录 -->
    <el-card style="margin-top: 20px;">
      <div slot="header" class="clearfix">
        <span>定价历史记录</span>
      </div>

      <el-table
        :data="pricingHistory"
        border
        style="width: 100%"
      >
        <el-table-column
          label="时间"
          prop="changeTime"
          width="160"
        >
          <template slot-scope="{row}">
            {{ row.changeTime | parseTime('{y}-{m}-{d} {h}:{i}') }}
          </template>
        </el-table-column>
        <el-table-column
          label="国家"
          prop="country"
          width="120"
        />
        <el-table-column
          label="时效性"
          prop="validity"
          width="120"
        >
          <template slot-scope="{row}">
            {{ getValidityText(row.validity) }}
          </template>
        </el-table-column>
        <el-table-column
          label="变更前成本价"
          prop="oldCostPrice"
          width="120"
          align="center"
        />
        <el-table-column
          label="变更后成本价"
          prop="newCostPrice"
          width="120"
          align="center"
        />
        <el-table-column
          label="变更前销售价"
          prop="oldSellPrice"
          width="120"
          align="center"
        />
        <el-table-column
          label="变更后销售价"
          prop="newSellPrice"
          width="120"
          align="center"
        />
        <el-table-column
          label="操作人"
          prop="operator"
          width="100"
        />
        <el-table-column
          label="备注"
          prop="remark"
          min-width="150"
        />
      </el-table>
    </el-card>
  </div>
</template>

<script>
import { parseTime } from '@/utils'
import i18nMixin from '@/mixins/i18n'

export default {
  name: 'DataPricing',
  filters: {
    parseTime
  },
  mixins: [i18nMixin],
  data() {
    return {
      pricingList: [],
      pricingHistory: []
    }
  },
  created() {
    this.getPricingList()
    this.getPricingHistory()
  },
  methods: {
    getPricingList() {
      // 模拟获取定价列表
      this.pricingList = [
        {
          id: 1,
          country: '孟加拉国',
          validity: '3',
          costPrice: 0.04,
          sellPrice: 0.05,
          profitRate: 25,
          dataCount: 500000,
          updateTime: new Date(),
          saving: false
        },
        {
          id: 2,
          country: '孟加拉国',
          validity: '30',
          costPrice: 0.03,
          sellPrice: 0.04,
          profitRate: 33.3,
          dataCount: 800000,
          updateTime: new Date(),
          saving: false
        },
        {
          id: 3,
          country: '孟加拉国',
          validity: '30+',
          costPrice: 0.02,
          sellPrice: 0.03,
          profitRate: 50,
          dataCount: 1200000,
          updateTime: new Date(),
          saving: false
        },
        {
          id: 4,
          country: '印度',
          validity: '3',
          costPrice: 0.04,
          sellPrice: 0.05,
          profitRate: 25,
          dataCount: 300000,
          updateTime: new Date(),
          saving: false
        },
        {
          id: 5,
          country: '印度',
          validity: '30',
          costPrice: 0.03,
          sellPrice: 0.04,
          profitRate: 33.3,
          dataCount: 600000,
          updateTime: new Date(),
          saving: false
        },
        {
          id: 6,
          country: '印度',
          validity: '30+',
          costPrice: 0.02,
          sellPrice: 0.03,
          profitRate: 50,
          dataCount: 900000,
          updateTime: new Date(),
          saving: false
        }
      ]
    },
    getPricingHistory() {
      // 模拟获取定价历史
      this.pricingHistory = [
        {
          changeTime: new Date('2023-12-01 10:30:00'),
          country: '孟加拉国',
          validity: '3',
          oldCostPrice: 0.035,
          newCostPrice: 0.04,
          oldSellPrice: 0.045,
          newSellPrice: 0.05,
          operator: '管理员',
          remark: '根据市场行情调整'
        },
        {
          changeTime: new Date('2023-11-15 14:20:00'),
          country: '印度',
          validity: '30',
          oldCostPrice: 0.025,
          newCostPrice: 0.03,
          oldSellPrice: 0.035,
          newSellPrice: 0.04,
          operator: '管理员',
          remark: '成本上涨调整'
        }
      ]
    },
    handlePriceChange(row) {
      if (row.costPrice > 0 && row.sellPrice > 0) {
        row.profitRate = ((row.sellPrice - row.costPrice) / row.costPrice * 100).toFixed(1)
      }
    },
    savePricing(row) {
      row.saving = true

      // 模拟保存过程
      setTimeout(() => {
        this.$message.success('定价保存成功')
        row.updateTime = new Date()
        row.saving = false

        // 添加到历史记录
        this.pricingHistory.unshift({
          changeTime: new Date(),
          country: row.country,
          validity: row.validity,
          oldCostPrice: row.costPrice,
          newCostPrice: row.costPrice,
          oldSellPrice: row.sellPrice,
          newSellPrice: row.sellPrice,
          operator: '当前用户',
          remark: '手动调整定价'
        })
      }, 1000)
    },
    formatNumber(num) {
      return num.toLocaleString()
    },
    getValidityText(validity) {
      const validityMap = {
        '3': '3天内',
        '30': '30天内',
        '30+': '30天以上'
      }
      return validityMap[validity] || validity
    },
    getValidityTagType(validity) {
      const tagMap = {
        '3': 'danger',
        '30': 'warning',
        '30+': 'success'
      }
      return tagMap[validity]
    },
    getProfitClass(profitRate) {
      if (profitRate >= 40) return 'profit-high'
      if (profitRate >= 25) return 'profit-medium'
      return 'profit-low'
    }
  }
}
</script>

<style lang="scss" scoped>
.pricing-rule-card {
  .pricing-content {
    .price-item {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 10px;

      .price-label {
        font-weight: bold;
        color: #606266;
      }

      .price-value {
        font-weight: bold;

        &.cost {
          color: #f56c6c;
        }

        &.sell {
          color: #67c23a;
        }

        &.profit {
          color: #409eff;
        }
      }
    }
  }
}

.profit-high {
  color: #67c23a;
  font-weight: bold;
}

.profit-medium {
  color: #e6a23c;
  font-weight: bold;
}

.profit-low {
  color: #f56c6c;
  font-weight: bold;
}
</style>
