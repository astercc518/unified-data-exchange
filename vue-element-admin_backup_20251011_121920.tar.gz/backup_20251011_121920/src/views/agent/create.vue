<template>
  <div class="app-container">
    <el-card>
      <div slot="header" class="clearfix">
        <span>{{ $t('agent.create') }}</span>
        <el-button
          style="float: right; padding: 3px 0"
          type="text"
          @click="goBack"
        >
          {{ $t('common.back') }}
        </el-button>
      </div>

      <el-form
        ref="agentForm"
        :model="agentForm"
        :rules="rules"
        label-width="120px"
        class="agent-form"
      >
        <!-- 基本信息 -->
        <el-divider content-position="left">{{ $t('user.basicInfo') }}</el-divider>

        <el-row :gutter="20">
          <el-col :span="12">
            <el-form-item :label="$t('agent.agentName')" prop="agentName">
              <el-input
                v-model="agentForm.agentName"
                :placeholder="$t('agent.pleaseEnterAgentName')"
              />
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item :label="$t('agent.loginAccount')" prop="loginAccount">
              <el-input
                v-model="agentForm.loginAccount"
                :placeholder="$t('agent.pleaseEnterLoginAccount')"
              />
            </el-form-item>
          </el-col>
        </el-row>

        <el-row :gutter="20">
          <el-col :span="12">
            <el-form-item :label="$t('agent.loginPassword')" prop="loginPassword">
              <el-input
                v-model="agentForm.loginPassword"
                type="password"
                :placeholder="$t('agent.pleaseEnterLoginPassword')"
                show-password
              />
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item :label="$t('agent.level')" prop="level">
              <el-select
                v-model="agentForm.level"
                :placeholder="$t('agent.pleaseSelectLevel')"
                style="width: 100%"
              >
                <el-option
                  v-for="level in levelOptions"
                  :key="level.value"
                  :label="level.label"
                  :value="level.value"
                />
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>

        <el-row :gutter="20">
          <el-col :span="12">
            <el-form-item :label="$t('agent.commission')" prop="commission">
              <el-input-number
                v-model="agentForm.commission"
                :min="0"
                :max="100"
                :precision="2"
                style="width: 100%"
                controls-position="right"
              />
              <span style="margin-left: 10px;">%</span>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item :label="$t('user.email')" prop="email">
              <el-input
                v-model="agentForm.email"
                :placeholder="$t('user.pleaseEnterEmail')"
              />
            </el-form-item>
          </el-col>
        </el-row>

        <!-- 数据权限 -->
        <el-divider content-position="left">{{ $t('user.dataPermission') }}</el-divider>

        <el-row :gutter="20">
          <el-col :span="12">
            <el-form-item :label="$t('user.dataCountry')" prop="dataCountry">
              <el-select
                v-model="agentForm.dataCountry"
                :placeholder="$t('user.pleaseSelectDataCountry')"
                style="width: 100%"
                filterable
                multiple
              >
                <el-option
                  v-for="country in countryOptions"
                  :key="country.value"
                  :label="country.label"
                  :value="country.value"
                />
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item :label="$t('user.dataValidity')" prop="dataValidity">
              <el-select
                v-model="agentForm.dataValidity"
                :placeholder="$t('user.pleaseSelectDataValidity')"
                style="width: 100%"
                multiple
              >
                <el-option
                  v-for="validity in validityOptions"
                  :key="validity.value"
                  :label="validity.label"
                  :value="validity.value"
                />
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>

        <el-form-item :label="$t('user.remark')" prop="remark">
          <el-input
            v-model="agentForm.remark"
            :placeholder="$t('user.remark')"
            type="textarea"
            :rows="3"
          />
        </el-form-item>

        <!-- 操作按钮 -->
        <el-form-item>
          <el-button
            type="primary"
            :loading="submitLoading"
            @click="submitForm"
          >
            {{ $t('common.save') }}
          </el-button>
          <el-button @click="resetForm">
            {{ $t('common.reset') }}
          </el-button>
          <el-button @click="goBack">
            {{ $t('common.cancel') }}
          </el-button>
        </el-form-item>
      </el-form>
    </el-card>
  </div>
</template>

<script>
import i18nMixin from '@/mixins/i18n'

export default {
  name: 'CreateAgent',
  mixins: [i18nMixin],
  data() {
    // 登录账号验证
    const validateLoginAccount = (rule, value, callback) => {
      if (!value) {
        callback(new Error(this.$t('agent.pleaseEnterLoginAccount')))
      } else if (value.length < 3) {
        callback(new Error('登录账号至少3个字符'))
      } else {
        callback()
      }
    }

    // 密码验证
    const validatePassword = (rule, value, callback) => {
      if (!value) {
        callback(new Error(this.$t('agent.pleaseEnterLoginPassword')))
      } else if (value.length < 6) {
        callback(new Error('密码至少6个字符'))
      } else {
        callback()
      }
    }

    // 邮箱验证
    const validateEmail = (rule, value, callback) => {
      if (!value) {
        callback(new Error(this.$t('user.pleaseEnterEmail')))
      } else {
        const emailReg = /^[a-zA-Z0-9_-]+@[a-zA-Z0-9_-]+(\.[a-zA-Z0-9_-]+)+$/
        if (!emailReg.test(value)) {
          callback(new Error(this.$t('user.invalidEmail')))
        } else {
          callback()
        }
      }
    }

    return {
      agentForm: {
        agentName: '',
        loginAccount: '',
        loginPassword: '',
        level: 1,
        commission: 10.0,
        dataCountry: [],
        dataValidity: [],
        email: '',
        remark: ''
      },
      levelOptions: [
        { value: 1, label: '一级代理' },
        { value: 2, label: '二级代理' },
        { value: 3, label: '三级代理' }
      ],
      countryOptions: [
        { value: 'ALL', label: '全部' },
        { value: 'US', label: '美国' },
        { value: 'UK', label: '英国' },
        { value: 'CN', label: '中国' },
        { value: 'JP', label: '日本' },
        { value: 'KR', label: '韩国' },
        { value: 'DE', label: '德国' },
        { value: 'FR', label: '法国' },
        { value: 'IT', label: '意大利' },
        { value: 'CA', label: '加拿大' },
        { value: 'AU', label: '澳大利亚' }
      ],
      validityOptions: [
        { value: '3days', label: '3天内' },
        { value: '30days', label: '30天内' },
        { value: '30plus', label: '30天以上' }
      ],
      rules: {
        agentName: [{ required: true, message: this.$t('agent.pleaseEnterAgentName'), trigger: 'blur' }],
        loginAccount: [{ required: true, validator: validateLoginAccount, trigger: 'blur' }],
        loginPassword: [{ required: true, validator: validatePassword, trigger: 'blur' }],
        level: [{ required: true, message: this.$t('agent.pleaseSelectLevel'), trigger: 'change' }],
        commission: [{ required: true, message: this.$t('agent.pleaseEnterCommission'), trigger: 'blur' }],
        dataCountry: [{ required: true, message: this.$t('user.pleaseSelectDataCountry'), trigger: 'change' }],
        dataValidity: [{ required: true, message: this.$t('user.pleaseSelectDataValidity'), trigger: 'change' }],
        email: [{ required: true, validator: validateEmail, trigger: 'blur' }]
      },
      submitLoading: false
    }
  },
  methods: {
    submitForm() {
      this.$refs.agentForm.validate((valid) => {
        if (valid) {
          this.submitLoading = true

          // 从localStorage获取现有代理列表
          const savedAgents = localStorage.getItem('agentList')
          let agents = []
          let newId = 1

          if (savedAgents) {
            try {
              agents = JSON.parse(savedAgents)
              // 获取最大ID
              const maxId = agents.reduce((max, agent) => Math.max(max, agent.id || 0), 0)
              newId = maxId + 1
            } catch (e) {
              console.error('解析代理数据失败:', e)
            }
          }

          // 创建新代理对象
          const newAgent = {
            id: newId,
            agentName: this.agentForm.agentName,
            loginAccount: this.agentForm.loginAccount,
            loginPassword: this.agentForm.loginPassword,
            level: this.agentForm.level,
            commission: this.agentForm.commission,
            dataCountry: this.agentForm.dataCountry,
            dataValidity: this.agentForm.dataValidity,
            email: this.agentForm.email,
            remark: this.agentForm.remark,
            status: 1,
            bindUsers: 0,
            totalCommission: 0,
            createTime: new Date().getTime()
          }

          // 添加到代理列表
          agents.push(newAgent)

          // 保存到localStorage
          localStorage.setItem('agentList', JSON.stringify(agents))

          console.log('创建代理数据:', newAgent)

          setTimeout(() => {
            this.$message({
              type: 'success',
              message: this.$t('agent.createAgentSuccess')
            })
            this.submitLoading = false
            this.$router.push('/user/agent-list')
          }, 800)
        } else {
          return false
        }
      })
    },
    resetForm() {
      this.$refs.agentForm.resetFields()
    },
    goBack() {
      this.$router.go(-1)
    }
  }
}
</script>

<style lang="scss" scoped>
.agent-form {
  max-width: 800px;
  margin: 0 auto;
}
</style>
