/**
 * 全球运营商号段信息数据库
 * 包含主要国家的运营商及其号段分布信息
 */

export const operatorData = {
  // 美国运营商
  'US': {
    operators: [
      {
        name: 'Verizon',
        marketShare: 35,
        numberSegments: ['310-004', '310-012', '311-480', '310-010'],
        description: '美国最大的无线运营商'
      },
      {
        name: 'AT&T',
        marketShare: 32,
        numberSegments: ['310-030', '310-070', '310-150', '310-170'],
        description: '美国第二大无线运营商'
      },
      {
        name: 'T-Mobile',
        marketShare: 20,
        numberSegments: ['310-160', '310-200', '310-210', '310-220'],
        description: '美国第三大无线运营商'
      },
      {
        name: 'Sprint',
        marketShare: 13,
        numberSegments: ['310-120', '311-870', '311-490', '312-530'],
        description: '已被T-Mobile收购'
      }
    ]
  },

  // 孟加拉国运营商
  'BD': {
    operators: [
      {
        name: 'Grameenphone',
        marketShare: 46,
        numberSegments: ['017', '013', '019'],
        description: '孟加拉国最大的移动运营商'
      },
      {
        name: 'Robi',
        marketShare: 29,
        numberSegments: ['018', '019'],
        description: '孟加拉国第二大运营商'
      },
      {
        name: 'Banglalink',
        marketShare: 20,
        numberSegments: ['014', '019'],
        description: '孟加拉国第三大运营商'
      },
      {
        name: 'Teletalk',
        marketShare: 5,
        numberSegments: ['015'],
        description: '孟加拉国国有运营商'
      }
    ]
  },

  // 印度运营商
  'IN': {
    operators: [
      {
        name: 'Jio',
        marketShare: 40,
        numberSegments: ['6', '7', '8', '9'],
        description: '印度最大的4G运营商'
      },
      {
        name: 'Airtel',
        marketShare: 32,
        numberSegments: ['6', '7', '8', '9'],
        description: '印度第二大运营商'
      },
      {
        name: 'Vi (Vodafone Idea)',
        marketShare: 23,
        numberSegments: ['6', '7', '8', '9'],
        description: 'Vodafone和Idea合并后的运营商'
      },
      {
        name: 'BSNL',
        marketShare: 5,
        numberSegments: ['6', '7', '8', '9'],
        description: '印度国有运营商'
      }
    ]
  },

  // 巴基斯坦运营商
  'PK': {
    operators: [
      {
        name: 'Jazz',
        marketShare: 38,
        numberSegments: ['030', '031', '032', '033'],
        description: '巴基斯坦最大的移动运营商'
      },
      {
        name: 'Telenor',
        marketShare: 29,
        numberSegments: ['034', '035'],
        description: '挪威Telenor在巴基斯坦的子公司'
      },
      {
        name: 'Zong',
        marketShare: 20,
        numberSegments: ['031', '032'],
        description: '中国移动巴基斯坦子公司'
      },
      {
        name: 'Ufone',
        marketShare: 13,
        numberSegments: ['033', '037'],
        description: '巴基斯坦电信旗下移动品牌'
      }
    ]
  },

  // 泰国运营商
  'TH': {
    operators: [
      {
        name: 'AIS',
        marketShare: 45,
        numberSegments: ['081', '082', '083', '084', '085'],
        description: '泰国最大的移动运营商'
      },
      {
        name: 'DTAC',
        marketShare: 28,
        numberSegments: ['089', '090', '091', '092'],
        description: '泰国第二大运营商'
      },
      {
        name: 'TrueMove H',
        marketShare: 22,
        numberSegments: ['086', '087', '088'],
        description: 'True Corporation旗下移动品牌'
      },
      {
        name: 'CAT Telecom',
        marketShare: 5,
        numberSegments: ['093', '094'],
        description: '泰国国有电信运营商'
      }
    ]
  },

  // 印度尼西亚运营商
  'ID': {
    operators: [
      {
        name: 'Telkomsel',
        marketShare: 42,
        numberSegments: ['0811', '0812', '0813', '0821', '0822', '0852', '0853'],
        description: '印尼最大的移动运营商'
      },
      {
        name: 'Indosat Ooredoo',
        marketShare: 25,
        numberSegments: ['0814', '0815', '0816', '0855', '0856', '0857', '0858'],
        description: '印尼第二大运营商'
      },
      {
        name: 'XL Axiata',
        marketShare: 20,
        numberSegments: ['0817', '0818', '0819', '0859', '0877', '0878'],
        description: '马来西亚Axiata在印尼的子公司'
      },
      {
        name: '3 (Tri)',
        marketShare: 13,
        numberSegments: ['0895', '0896', '0897', '0898', '0899'],
        description: '印尼第四大移动运营商'
      }
    ]
  },

  // 中国运营商
  'CN': {
    operators: [
      {
        name: '中国移动',
        marketShare: 65,
        numberSegments: ['134', '135', '136', '137', '138', '139', '150', '151', '152', '157', '158', '159', '182', '183', '184', '187', '188', '198'],
        description: '中国最大的移动运营商'
      },
      {
        name: '中国联通',
        marketShare: 20,
        numberSegments: ['130', '131', '132', '155', '156', '166', '185', '186', '196'],
        description: '中国第二大运营商'
      },
      {
        name: '中国电信',
        marketShare: 15,
        numberSegments: ['133', '149', '153', '173', '177', '180', '181', '189', '199'],
        description: '中国第三大运营商'
      }
    ]
  },

  // 英国运营商
  'GB': {
    operators: [
      {
        name: 'EE',
        marketShare: 35,
        numberSegments: ['074', '075', '076', '077'],
        description: '英国最大的移动运营商'
      },
      {
        name: 'O2',
        marketShare: 25,
        numberSegments: ['078', '079'],
        description: '西班牙Telefónica旗下英国品牌'
      },
      {
        name: 'Three',
        marketShare: 22,
        numberSegments: ['071', '072', '073'],
        description: '和记电讯旗下英国品牌'
      },
      {
        name: 'Vodafone',
        marketShare: 18,
        numberSegments: ['070', '071'],
        description: '英国老牌运营商'
      }
    ]
  },

  // 德国运营商
  'DE': {
    operators: [
      {
        name: 'Deutsche Telekom',
        marketShare: 38,
        numberSegments: ['0151', '0160', '0170', '0171', '0175'],
        description: '德国电信，欧洲最大的电信运营商'
      },
      {
        name: 'Vodafone',
        marketShare: 32,
        numberSegments: ['0152', '0162', '0172', '0173', '0174'],
        description: 'Vodafone德国分公司'
      },
      {
        name: 'Telefónica Germany (O2)',
        marketShare: 30,
        numberSegments: ['0159', '0176', '0177', '0178', '0179'],
        description: '西班牙Telefónica德国子公司'
      }
    ]
  }
}

/**
 * 根据国家代码获取运营商信息
 * @param {string} countryCode - 国家代码
 * @returns {Array} 运营商列表
 */
export function getOperatorsByCountry(countryCode) {
  const countryData = operatorData[countryCode]
  return countryData ? countryData.operators : []
}

/**
 * 根据运营商市场份额分配数量
 * @param {number} totalQuantity - 总数量
 * @param {string} countryCode - 国家代码
 * @returns {Array} 运营商分布
 */
export function distributeQuantityByOperators(totalQuantity, countryCode) {
  const operators = getOperatorsByCountry(countryCode)

  if (operators.length === 0) {
    // 如果没有具体的运营商信息，返回默认分布
    return [
      { name: '主要运营商', count: Math.floor(totalQuantity * 0.6) },
      { name: '其他运营商', count: Math.floor(totalQuantity * 0.4) }
    ]
  }

  const distribution = []
  let remaining = totalQuantity

  // 按市场份额分配
  for (let i = 0; i < operators.length; i++) {
    const operator = operators[i]
    if (i === operators.length - 1) {
      // 最后一个运营商分配剩余数量
      distribution.push({
        name: operator.name,
        count: remaining,
        marketShare: operator.marketShare,
        segments: operator.numberSegments
      })
    } else {
      // 按市场份额分配
      const count = Math.floor(totalQuantity * (operator.marketShare / 100))
      distribution.push({
        name: operator.name,
        count: count,
        marketShare: operator.marketShare,
        segments: operator.numberSegments
      })
      remaining -= count
    }
  }

  return distribution
}

/**
 * 获取运营商详细信息
 * @param {string} countryCode - 国家代码
 * @param {string} operatorName - 运营商名称
 * @returns {Object|null} 运营商详细信息
 */
export function getOperatorDetails(countryCode, operatorName) {
  const operators = getOperatorsByCountry(countryCode)
  return operators.find(op => op.name === operatorName) || null
}
