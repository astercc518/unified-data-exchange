<template>
  <div class="app-container">
    <!-- 数据统计卡片 -->
    <el-row :gutter="20" style="margin-bottom: 20px;">
      <el-col :span="6">
        <el-card class="stat-card">
          <div class="stat-content">
            <div class="stat-number">{{ formatNumber(statistics.total) }}</div>
            <div class="stat-label">总数据量</div>
          </div>
          <i class="el-icon-data-line stat-icon" />
        </el-card>
      </el-col>
      <el-col :span="6">
        <el-card class="stat-card">
          <div class="stat-content">
            <div class="stat-number">{{ formatNumber(statistics.day3) }}</div>
            <div class="stat-label">3天内数据</div>
          </div>
          <i class="el-icon-time stat-icon" />
        </el-card>
      </el-col>
      <el-col :span="6">
        <el-card class="stat-card">
          <div class="stat-content">
            <div class="stat-number">{{ formatNumber(statistics.day30) }}</div>
            <div class="stat-label">30天内数据</div>
          </div>
          <i class="el-icon-date stat-icon" />
        </el-card>
      </el-col>
      <el-col :span="6">
        <el-card class="stat-card">
          <div class="stat-content">
            <div class="stat-number">{{ formatNumber(statistics.over30) }}</div>
            <div class="stat-label">30天以上数据</div>
          </div>
          <i class="el-icon-folder stat-icon" />
        </el-card>
      </el-col>
    </el-row>

    <!-- 筛选条件和操作按钮 -->
    <el-card style="margin-bottom: 20px;">
      <div class="filter-container">
        <el-select
          v-model="listQuery.country"
          :placeholder="$t('data.selectCountry')"
          filterable
          clearable
          style="width: 200px"
          class="filter-item"
        >
          <el-option
            v-for="country in countryOptions"
            :key="country.value"
            :label="country.label"
            :value="country.value"
          />
        </el-select>

        <el-select
          v-model="listQuery.validity"
          :placeholder="$t('data.selectValidity')"
          clearable
          style="width: 120px"
          class="filter-item"
        >
          <el-option :label="$t('data.validityDay3')" value="3" />
          <el-option :label="$t('data.validityDay30')" value="30" />
          <el-option :label="$t('data.validityOver30')" value="30+" />
        </el-select>

        <el-select
          v-model="listQuery.dataType"
          placeholder="数据类型"
          clearable
          style="width: 150px"
          class="filter-item"
        >
          <el-option
            v-for="type in dataTypeOptions"
            :key="type.value"
            :label="type.label"
            :value="type.value"
          />
        </el-select>

        <el-input
          v-model="listQuery.source"
          :placeholder="$t('data.source')"
          style="width: 200px;"
          class="filter-item"
          @keyup.enter.native="handleFilter"
        />

        <el-button
          v-waves
          class="filter-item"
          type="primary"
          icon="el-icon-search"
          @click="handleFilter"
        >
          {{ $t('common.search') }}
        </el-button>

        <el-button
          class="filter-item"
          type="success"
          icon="el-icon-plus"
          @click="handleCreate"
        >
          新增数据
        </el-button>

        <el-button
          class="filter-item"
          type="warning"
          icon="el-icon-refresh"
          @click="refreshData"
        >
          刷新数据
        </el-button>
      </div>
    </el-card>

    <!-- 数据列表 -->
    <el-card>
      <div slot="header" class="clearfix">
        <span>已上传数据列表 ({{ total }}条)</span>
      </div>

      <el-table
        :key="tableKey"
        v-loading="listLoading"
        :data="list"
        border
        fit
        highlight-current-row
        style="width: 100%;"
        @sort-change="sortChange"
      >
        <el-table-column
          label="ID"
          prop="id"
          sortable="custom"
          align="center"
          width="80"
        />
        <el-table-column
          :label="$t('data.country')"
          prop="country"
          width="120"
        />
        <el-table-column
          label="数据类型"
          prop="dataType"
          width="100"
        />
        <el-table-column
          :label="$t('data.validity')"
          prop="validity"
          width="100"
          align="center"
        >
          <template slot-scope="{row}">
            <el-tag :type="getValidityTagType(row.validity)">
              {{ getValidityText(row.validity) }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column
          :label="$t('data.source')"
          prop="source"
          min-width="150"
          show-overflow-tooltip
        />
        <el-table-column
          :label="$t('data.quantity')"
          prop="availableQuantity"
          width="120"
          align="center"
          sortable="custom"
        >
          <template slot-scope="{row}">
            {{ formatNumber(row.availableQuantity) }}
          </template>
        </el-table-column>
        <el-table-column
          label="运营商分布"
          min-width="200"
        >
          <template slot-scope="{row}">
            <div v-for="operator in row.operators" :key="operator.name" class="operator-item">
              <span class="operator-name">{{ operator.name }}:</span>
              <span class="operator-count">{{ formatNumber(operator.count) }}</span>
              <span class="operator-percent">({{ (operator.count / row.availableQuantity * 100).toFixed(1) }}%)</span>
            </div>
          </template>
        </el-table-column>
        <el-table-column
          :label="$t('data.costPrice')"
          prop="costPrice"
          width="100"
          align="center"
          sortable="custom"
        >
          <template slot-scope="{row}">
            {{ row.costPrice }} U
          </template>
        </el-table-column>
        <el-table-column
          :label="$t('data.sellPrice')"
          prop="sellPrice"
          width="100"
          align="center"
          sortable="custom"
        >
          <template slot-scope="{row}">
            {{ row.sellPrice }} U
          </template>
        </el-table-column>
        <el-table-column
          label="利润率"
          width="80"
          align="center"
        >
          <template slot-scope="{row}">
            <span :class="getProfitClass(row)">
              {{ calculateProfitRate(row) }}%
            </span>
          </template>
        </el-table-column>
        <el-table-column
          label="上传时间"
          prop="uploadTime"
          width="150"
          align="center"
          sortable="custom"
        >
          <template slot-scope="{row}">
            {{ row.uploadTime | parseTime('{y}-{m}-{d} {h}:{i}') }}
          </template>
        </el-table-column>
        <el-table-column
          label="状态"
          width="100"
          align="center"
        >
          <template slot-scope="{row}">
            <el-tag :type="getStatusType(row.status)">
              {{ getStatusText(row.status) }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column
          :label="$t('common.operation')"
          align="center"
          width="280"
          class-name="small-padding fixed-width"
        >
          <template slot-scope="{row}">
            <el-button
              type="primary"
              size="mini"
              @click="handleDetail(row)"
            >
              {{ $t('common.detail') }}
            </el-button>
            <el-button
              type="info"
              size="mini"
              @click="handleEdit(row)"
            >
              {{ $t('common.edit') }}
            </el-button>
            <el-button
              type="success"
              size="mini"
              @click="handlePricing(row)"
            >
              定价
            </el-button>
            <el-button
              size="mini"
              type="danger"
              @click="handleDelete(row)"
            >
              {{ $t('common.delete') }}
            </el-button>
          </template>
        </el-table-column>
      </el-table>

      <!-- 分页 -->
      <pagination
        v-show="total>0"
        :total="total"
        :page.sync="listQuery.page"
        :limit.sync="listQuery.limit"
        @pagination="getList"
      />
    </el-card>

    <!-- 数据详情对话框 -->
    <el-dialog
      title="数据详情"
      :visible.sync="detailDialogVisible"
      width="700px"
    >
      <el-descriptions v-if="currentData" :column="2" border>
        <el-descriptions-item label="数据ID">
          {{ currentData.id }}
        </el-descriptions-item>
        <el-descriptions-item label="国家">
          {{ currentData.country }}
        </el-descriptions-item>
        <el-descriptions-item label="数据类型">
          {{ currentData.dataType }}
        </el-descriptions-item>
        <el-descriptions-item label="时效性">
          {{ getValidityText(currentData.validity) }}
        </el-descriptions-item>
        <el-descriptions-item label="数据来源">
          {{ currentData.source }}
        </el-descriptions-item>
        <el-descriptions-item label="总数量">
          {{ formatNumber(currentData.availableQuantity) }}
        </el-descriptions-item>
        <el-descriptions-item label="成本价">
          {{ currentData.costPrice }} U/条
        </el-descriptions-item>
        <el-descriptions-item label="销售价">
          {{ currentData.sellPrice }} U/条
        </el-descriptions-item>
        <el-descriptions-item label="利润率">
          {{ calculateProfitRate(currentData) }}%
        </el-descriptions-item>
        <el-descriptions-item label="状态">
          <el-tag :type="getStatusType(currentData.status)">
            {{ getStatusText(currentData.status) }}
          </el-tag>
        </el-descriptions-item>
        <el-descriptions-item label="运营商分布" :span="2">
          <div v-for="operator in currentData.operators" :key="operator.name" class="operator-detail">
            <el-tag class="operator-tag">
              {{ operator.name }}: {{ formatNumber(operator.count) }} ({{ (operator.count / currentData.availableQuantity * 100).toFixed(1) }}%)
            </el-tag>
          </div>
        </el-descriptions-item>
        <el-descriptions-item label="备注" :span="2">
          {{ currentData.remark || '无' }}
        </el-descriptions-item>
        <el-descriptions-item label="上传时间" :span="2">
          {{ currentData.uploadTime | parseTime('{y}-{m}-{d} {h}:{i}:{s}') }}
        </el-descriptions-item>
      </el-descriptions>
    </el-dialog>

    <!-- 编辑数据对话框 -->
    <el-dialog
      :title="editForm.id ? '编辑数据' : '新增数据'"
      :visible.sync="editDialogVisible"
      width="800px"
      @close="resetEditForm"
    >
      <el-form
        ref="editForm"
        :model="editForm"
        :rules="editRules"
        label-width="120px"
      >
        <el-row :gutter="20">
          <el-col :span="8">
            <el-form-item label="国家" prop="country">
              <el-input
                v-model="editForm.country"
                placeholder="请输入国家名称"
              />
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="数据类型" prop="dataType">
              <el-input
                v-model="editForm.dataType"
                placeholder="请输入数据类型"
              />
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="数据来源" prop="source">
              <el-input
                v-model="editForm.source"
                placeholder="请输入数据来源"
              />
            </el-form-item>
          </el-col>
        </el-row>

        <el-row :gutter="20">
          <el-col :span="8">
            <el-form-item label="时效性" prop="validity">
              <el-select
                v-model="editForm.validity"
                placeholder="请选择时效性"
                style="width: 100%"
              >
                <el-option label="3天内" value="3" />
                <el-option label="30天内" value="30" />
                <el-option label="30天以上" value="30+" />
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="数量" prop="availableQuantity">
              <el-input-number
                v-model="editForm.availableQuantity"
                :min="1"
                :max="10000000"
                style="width: 100%"
                controls-position="right"
                placeholder="请输入数据数量"
              />
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="状态" prop="status">
              <el-select
                v-model="editForm.status"
                placeholder="请选择状态"
                style="width: 100%"
              >
                <el-option label="可用" value="available" />
                <el-option label="停用" value="disabled" />
                <el-option label="已售完" value="sold_out" />
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>

        <el-row :gutter="20">
          <el-col :span="12">
            <el-form-item label="成本价" prop="costPrice">
              <el-input-number
                v-model="editForm.costPrice"
                :min="0"
                :precision="4"
                style="width: 100%"
                controls-position="right"
                placeholder="请输入成本价"
              />
              <span style="margin-left: 10px;">U/条</span>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="销售价" prop="sellPrice">
              <el-input-number
                v-model="editForm.sellPrice"
                :min="0"
                :precision="4"
                style="width: 100%"
                controls-position="right"
                placeholder="请输入销售价"
              />
              <span style="margin-left: 10px;">U/条</span>
            </el-form-item>
          </el-col>
        </el-row>

        <el-row>
          <el-col :span="24">
            <el-form-item label="备注">
              <el-input
                v-model="editForm.remark"
                type="textarea"
                :rows="3"
                placeholder="请输入备注信息（可选）"
                :maxlength="500"
                show-word-limit
              />
            </el-form-item>
          </el-col>
        </el-row>

        <div v-if="editForm.costPrice > 0 && editForm.sellPrice > 0" class="profit-info">
          <el-alert
            :title="`利润率: ${calculateProfitRate(editForm)}%`"
            :type="getProfitAlertType(editForm)"
            show-icon
            :closable="false"
          />
        </div>
      </el-form>

      <div slot="footer" class="dialog-footer">
        <el-button @click="editDialogVisible = false">取 消</el-button>
        <el-button type="primary" @click="handleSave">确 定</el-button>
      </div>
    </el-dialog>

    <!-- 定价对话框 -->
    <el-dialog
      title="数据定价"
      :visible.sync="pricingDialogVisible"
      width="600px"
    >
      <el-form
        ref="pricingForm"
        :model="pricingForm"
        :rules="pricingRules"
        label-width="120px"
      >
        <el-form-item label="数据信息">
          <el-descriptions :column="2" size="small">
            <el-descriptions-item label="国家">{{ pricingForm.country }}</el-descriptions-item>
            <el-descriptions-item label="数据类型">{{ pricingForm.dataType }}</el-descriptions-item>
            <el-descriptions-item label="数量">{{ formatNumber(pricingForm.availableQuantity) }}</el-descriptions-item>
            <el-descriptions-item label="时效性">{{ getValidityText(pricingForm.validity) }}</el-descriptions-item>
          </el-descriptions>
        </el-form-item>

        <el-form-item label="推荐定价" class="recommended-pricing">
          <el-button
            type="success"
            size="small"
            @click="applyRecommendedPricing"
          >
            应用推荐定价
          </el-button>
          <div class="pricing-tips">
            <small>根据时效性自动计算推荐价格</small>
          </div>
        </el-form-item>

        <el-row :gutter="20">
          <el-col :span="12">
            <el-form-item label="成本价" prop="costPrice">
              <el-input-number
                v-model="pricingForm.costPrice"
                :min="0"
                :precision="4"
                style="width: 100%"
                controls-position="right"
              />
              <span style="margin-left: 10px;">U/条</span>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="销售价" prop="sellPrice">
              <el-input-number
                v-model="pricingForm.sellPrice"
                :min="0"
                :precision="4"
                style="width: 100%"
                controls-position="right"
              />
              <span style="margin-left: 10px;">U/条</span>
            </el-form-item>
          </el-col>
        </el-row>

        <el-form-item label="利润分析">
          <div class="profit-analysis">
            <p><strong>单条利润:</strong> {{ (pricingForm.sellPrice - pricingForm.costPrice).toFixed(4) }} U</p>
            <p><strong>利润率:</strong>
              <span :class="getProfitClass(pricingForm)">{{ calculateProfitRate(pricingForm) }}%</span>
            </p>
            <p><strong>总利润:</strong> {{ ((pricingForm.sellPrice - pricingForm.costPrice) * pricingForm.availableQuantity).toFixed(2) }} U</p>
          </div>
        </el-form-item>
      </el-form>

      <div slot="footer" class="dialog-footer">
        <el-button @click="pricingDialogVisible = false">取 消</el-button>
        <el-button type="primary" @click="handleSavePricing">保存定价</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import { parseTime } from '@/utils'
import Pagination from '@/components/Pagination'
import waves from '@/directive/waves'
import i18nMixin from '@/mixins/i18n'
import { distributeQuantityByOperators } from '@/data/operators'

export default {
  name: 'DataLibrary',
  components: { Pagination },
  directives: { waves },
  filters: {
    parseTime
  },
  mixins: [i18nMixin],
  data() {
    return {
      tableKey: 0,
      list: [],
      total: 0,
      listLoading: true,
      listQuery: {
        page: 1,
        limit: 20,
        country: undefined,
        validity: undefined,
        dataType: undefined,
        source: undefined,
        sort: '+id'
      },
      statistics: {
        total: 0,
        day3: 0,
        day30: 0,
        over30: 0
      },
      detailDialogVisible: false,
      editDialogVisible: false,
      pricingDialogVisible: false,
      currentData: null,
      countryOptions: [],
      dataTypeOptions: [],
      editForm: {
        id: null,
        country: '',
        countryCode: '',
        dataType: '',
        validity: '',
        source: '',
        availableQuantity: 0,
        costPrice: 0,
        sellPrice: 0,
        remark: '',
        status: 'available',
        operators: []
      },
      pricingForm: {
        id: null,
        country: '',
        dataType: '',
        validity: '',
        availableQuantity: 0,
        costPrice: 0,
        sellPrice: 0
      },
      editRules: {
        country: [{ required: true, message: '请输入国家名称', trigger: 'blur' }],
        dataType: [{ required: true, message: '请输入数据类型', trigger: 'blur' }],
        source: [{ required: true, message: '请输入数据来源', trigger: 'blur' }],
        validity: [{ required: true, message: '请选择时效性', trigger: 'change' }],
        availableQuantity: [{ required: true, message: '请输入数据数量', trigger: 'blur' }],
        costPrice: [{ required: true, message: '请输入成本价', trigger: 'blur' }],
        sellPrice: [{ required: true, message: '请输入销售价', trigger: 'blur' }],
        status: [{ required: true, message: '请选择状态', trigger: 'change' }]
      },
      pricingRules: {
        costPrice: [{ required: true, message: '请输入成本价', trigger: 'blur' }],
        sellPrice: [{ required: true, message: '请输入销售价', trigger: 'blur' }]
      }
    }
  },
  created() {
    this.getList()
    this.getStatistics()
    this.initOptions()
  },
  methods: {
    // 获取数据列表
    getList() {
      this.listLoading = true
      console.log('🔄 数据列表开始加载...')

      setTimeout(() => {
        try {
          // 从localStorage获取真实上传的数据
          const savedDataList = localStorage.getItem('dataList')
          let dataList = []

          if (savedDataList) {
            dataList = JSON.parse(savedDataList)
            console.log('📄 从localStorage加载数据:', dataList.length, '条')
          } else {
            console.log('🛠️ 未找到localStorage数据')
            dataList = []
          }

          // 应用筛选条件
          let filteredList = this.applyFilters(dataList)

          // 应用排序
          filteredList = this.applySorting(filteredList)

          // 分页
          const start = (this.listQuery.page - 1) * this.listQuery.limit
          const end = start + this.listQuery.limit

          this.list = filteredList.slice(start, end)
          this.total = filteredList.length
          this.listLoading = false

          console.log('✅ 数据加载完成，显示:', this.list.length, '条，总数:', this.total, '条')
        } catch (error) {
          console.error('❌ 加载数据失败:', error)
          this.list = []
          this.total = 0
          this.listLoading = false

          this.$message({
            type: 'error',
            message: '加载数据失败',
            duration: 3000
          })
        }
      }, 300)
    },

    // 获取统计数据
    getStatistics() {
      try {
        const savedDataList = localStorage.getItem('dataList')
        if (!savedDataList) {
          this.statistics = { total: 0, day3: 0, day30: 0, over30: 0 }
          return
        }

        const dataList = JSON.parse(savedDataList)
        let total = 0
        let day3 = 0
        let day30 = 0
        let over30 = 0

        dataList.forEach(item => {
          const quantity = item.availableQuantity || 0
          total += quantity

          switch (item.validity) {
            case '3':
              day3 += quantity
              break
            case '30':
              day30 += quantity
              break
            case '30+':
              over30 += quantity
              break
          }
        })

        this.statistics = { total, day3, day30, over30 }
        console.log('📊 统计数据更新:', this.statistics)
      } catch (error) {
        console.error('统计数据计算失败:', error)
        this.statistics = { total: 0, day3: 0, day30: 0, over30: 0 }
      }
    },

    // 初始化选项
    initOptions() {
      try {
        const savedDataList = localStorage.getItem('dataList')
        if (!savedDataList) return

        const dataList = JSON.parse(savedDataList)

        // 提取国家选项
        const countries = [...new Set(dataList.map(item => item.country))]
        this.countryOptions = countries.map(country => ({
          label: country,
          value: country
        }))

        // 提取数据类型选项
        const dataTypes = [...new Set(dataList.map(item => item.dataType).filter(Boolean))]
        this.dataTypeOptions = dataTypes.map(type => ({
          label: type,
          value: type
        }))
      } catch (error) {
        console.error('初始化选项失败:', error)
      }
    },

    // 应用筛选条件
    applyFilters(dataList) {
      let filteredList = [...dataList]

      // 国家筛选
      if (this.listQuery.country) {
        filteredList = filteredList.filter(item =>
          item.country && item.country.includes(this.listQuery.country)
        )
      }

      // 时效筛选
      if (this.listQuery.validity) {
        filteredList = filteredList.filter(item => item.validity === this.listQuery.validity)
      }

      // 数据类型筛选
      if (this.listQuery.dataType) {
        filteredList = filteredList.filter(item =>
          item.dataType && item.dataType.includes(this.listQuery.dataType)
        )
      }

      // 数据来源筛选
      if (this.listQuery.source) {
        filteredList = filteredList.filter(item =>
          item.source && item.source.toLowerCase().includes(this.listQuery.source.toLowerCase())
        )
      }

      return filteredList
    },

    // 应用排序
    applySorting(dataList) {
      const { sort } = this.listQuery
      if (!sort) return dataList

      const order = sort.charAt(0) === '+' ? 'asc' : 'desc'
      const field = sort.slice(1)

      return dataList.sort((a, b) => {
        let aVal = a[field]
        let bVal = b[field]

        // 处理日期类型
        if (field === 'uploadTime') {
          aVal = new Date(aVal).getTime()
          bVal = new Date(bVal).getTime()
        }

        if (order === 'asc') {
          return aVal > bVal ? 1 : -1
        } else {
          return aVal < bVal ? 1 : -1
        }
      })
    },

    // 筛选操作
    handleFilter() {
      this.listQuery.page = 1
      this.getList()
    },

    // 刷新数据
    refreshData() {
      this.getList()
      this.getStatistics()
      this.initOptions()
      this.$message({
        type: 'success',
        message: '数据刷新成功',
        duration: 2000
      })
    },

    // 查看详情
    handleDetail(row) {
      this.currentData = row
      this.detailDialogVisible = true
    },

    // 新增数据
    handleCreate() {
      this.resetEditForm()
      this.editDialogVisible = true
    },

    // 编辑数据
    handleEdit(row) {
      this.editForm = { ...row }
      this.editDialogVisible = true
    },

    // 定价操作
    handlePricing(row) {
      this.pricingForm = {
        id: row.id,
        country: row.country,
        dataType: row.dataType,
        validity: row.validity,
        availableQuantity: row.availableQuantity,
        costPrice: row.costPrice,
        sellPrice: row.sellPrice
      }
      this.pricingDialogVisible = true
    },

    // 删除数据
    handleDelete(row) {
      this.$confirm(`确认删除这批数据？\n国家: ${row.country}\n数据类型: ${row.dataType}\n数量: ${this.formatNumber(row.availableQuantity)}`, this.$t('common.warning'), {
        confirmButtonText: this.$t('common.confirm'),
        cancelButtonText: this.$t('common.cancel'),
        type: 'warning'
      }).then(() => {
        this.deleteData(row.id)
      }).catch(() => {})
    },

    // 执行删除操作
    deleteData(id) {
      try {
        const savedDataList = localStorage.getItem('dataList')
        if (!savedDataList) {
          this.$message.error('数据不存在')
          return
        }

        const dataList = JSON.parse(savedDataList)
        const filteredList = dataList.filter(item => item.id !== id)

        localStorage.setItem('dataList', JSON.stringify(filteredList))

        this.$message({
          type: 'success',
          message: '删除成功'
        })

        this.getList()
        this.getStatistics()
        this.initOptions()
      } catch (error) {
        console.error('删除数据失败:', error)
        this.$message.error('删除失败')
      }
    },

    // 保存编辑
    handleSave() {
      this.$refs.editForm.validate((valid) => {
        if (valid) {
          this.saveData()
        }
      })
    },

    // 执行保存操作
    saveData() {
      try {
        const savedDataList = localStorage.getItem('dataList')
        const dataList = savedDataList ? JSON.parse(savedDataList) : []

        if (this.editForm.id) {
          // 编辑模式
          const index = dataList.findIndex(item => item.id === this.editForm.id)
          if (index !== -1) {
            // 保留原有的运营商信息和上传时间
            const originalData = dataList[index]
            dataList[index] = {
              ...this.editForm,
              operators: originalData.operators || this.generateOperators(this.editForm.availableQuantity, this.editForm.countryCode),
              uploadTime: originalData.uploadTime || Date.now()
            }
          }
        } else {
          // 新增模式
          const maxId = dataList.reduce((max, item) => Math.max(max, item.id || 0), 0)
          const newData = {
            ...this.editForm,
            id: maxId + 1,
            operators: this.generateOperators(this.editForm.availableQuantity, this.editForm.countryCode),
            uploadTime: Date.now()
          }
          dataList.push(newData)
        }

        localStorage.setItem('dataList', JSON.stringify(dataList))

        this.$message({
          type: 'success',
          message: this.editForm.id ? '编辑成功' : '新增成功'
        })

        this.editDialogVisible = false
        this.getList()
        this.getStatistics()
        this.initOptions()
      } catch (error) {
        console.error('保存数据失败:', error)
        this.$message.error('保存失败')
      }
    },

    // 保存定价
    handleSavePricing() {
      this.$refs.pricingForm.validate((valid) => {
        if (valid) {
          this.savePricing()
        }
      })
    },

    // 执行定价保存
    savePricing() {
      try {
        const savedDataList = localStorage.getItem('dataList')
        if (!savedDataList) {
          this.$message.error('数据不存在')
          return
        }

        const dataList = JSON.parse(savedDataList)
        const index = dataList.findIndex(item => item.id === this.pricingForm.id)

        if (index !== -1) {
          dataList[index].costPrice = this.pricingForm.costPrice
          dataList[index].sellPrice = this.pricingForm.sellPrice

          localStorage.setItem('dataList', JSON.stringify(dataList))

          this.$message({
            type: 'success',
            message: '定价更新成功'
          })

          this.pricingDialogVisible = false
          this.getList()
        } else {
          this.$message.error('数据不存在')
        }
      } catch (error) {
        console.error('保存定价失败:', error)
        this.$message.error('保存定价失败')
      }
    },

    // 应用推荐定价
    applyRecommendedPricing() {
      const { validity } = this.pricingForm
      let costPrice = 0.02
      let sellPrice = 0.03

      // 根据记忆中的定价规则设置推荐价格
      switch (validity) {
        case '3':
          costPrice = 0.04
          sellPrice = 0.05
          break
        case '30':
          costPrice = 0.03
          sellPrice = 0.04
          break
        case '30+':
          costPrice = 0.02
          sellPrice = 0.03
          break
      }

      this.pricingForm.costPrice = costPrice
      this.pricingForm.sellPrice = sellPrice

      this.$message({
        type: 'success',
        message: '已应用推荐定价',
        duration: 2000
      })
    },

    // 重置编辑表单
    resetEditForm() {
      this.editForm = {
        id: null,
        country: '',
        countryCode: '',
        dataType: '',
        validity: '',
        source: '',
        availableQuantity: 0,
        costPrice: 0,
        sellPrice: 0,
        remark: '',
        status: 'available',
        operators: []
      }
    },

    // 排序处理
    sortChange(data) {
      const { prop, order } = data
      if (order === 'ascending') {
        this.listQuery.sort = `+${prop}`
      } else if (order === 'descending') {
        this.listQuery.sort = `-${prop}`
      } else {
        this.listQuery.sort = '+id'
      }
      this.handleFilter()
    },

    // 生成运营商分布
    generateOperators(totalQuantity, countryCode) {
      try {
        return distributeQuantityByOperators(totalQuantity, countryCode || 'DEFAULT')
      } catch (error) {
        console.error('生成运营商分布失败:', error)
        return [
          { name: '默认运营商', count: totalQuantity }
        ]
      }
    },

    // 格式化数字
    formatNumber(num) {
      return num ? num.toLocaleString() : '0'
    },

    // 获取时效性文本
    getValidityText(validity) {
      const validityMap = {
        '3': '3天内',
        '30': '30天内',
        '30+': '30天以上'
      }
      return validityMap[validity] || validity
    },

    // 获取时效性标签类型
    getValidityTagType(validity) {
      const tagMap = {
        '3': 'danger',
        '30': 'warning',
        '30+': 'success'
      }
      return tagMap[validity]
    },

    // 获取状态文本
    getStatusText(status) {
      const statusMap = {
        'available': '可用',
        'disabled': '停用',
        'sold_out': '已售完'
      }
      return statusMap[status] || status
    },

    // 获取状态类型
    getStatusType(status) {
      const typeMap = {
        'available': 'success',
        'disabled': 'warning',
        'sold_out': 'info'
      }
      return typeMap[status] || 'info'
    },

    // 计算利润率
    calculateProfitRate(data) {
      if (!data.costPrice || data.costPrice <= 0) return '0.00'
      const rate = ((data.sellPrice - data.costPrice) / data.costPrice * 100)
      return rate.toFixed(1)
    },

    // 获取利润率样式类
    getProfitClass(data) {
      const rate = parseFloat(this.calculateProfitRate(data))
      if (rate >= 50) return 'profit-high'
      if (rate >= 20) return 'profit-medium'
      if (rate >= 0) return 'profit-low'
      return 'profit-negative'
    },

    // 获取利润率提示类型
    getProfitAlertType(data) {
      const rate = parseFloat(this.calculateProfitRate(data))
      if (rate >= 50) return 'success'
      if (rate >= 20) return 'warning'
      if (rate >= 0) return 'info'
      return 'error'
    }
  }
}
</script>

<style lang="scss" scoped>
.filter-container {
  .filter-item {
    display: inline-block;
    vertical-align: middle;
    margin-right: 10px;
  }
}

.stat-card {
  position: relative;
  overflow: hidden;

  .stat-content {
    .stat-number {
      font-size: 24px;
      font-weight: bold;
      color: #409eff;
      margin-bottom: 5px;
    }

    .stat-label {
      font-size: 14px;
      color: #606266;
    }
  }

  .stat-icon {
    position: absolute;
    right: 20px;
    top: 50%;
    transform: translateY(-50%);
    font-size: 40px;
    color: #ddd;
  }
}

.operator-item {
  margin-bottom: 3px;
  font-size: 12px;

  .operator-name {
    font-weight: bold;
    margin-right: 5px;
  }

  .operator-count {
    color: #409eff;
    margin-right: 3px;
  }

  .operator-percent {
    color: #909399;
    font-size: 11px;
  }
}

.operator-detail {
  margin-bottom: 8px;

  .operator-tag {
    margin-right: 10px;
    margin-bottom: 5px;
  }
}

// 利润率样式
.profit-high {
  color: #67c23a;
  font-weight: bold;
}

.profit-medium {
  color: #e6a23c;
  font-weight: bold;
}

.profit-low {
  color: #409eff;
}

.profit-negative {
  color: #f56c6c;
  font-weight: bold;
}

// 对话框样式
.dialog-footer {
  text-align: right;
}

.profit-info {
  margin-top: 15px;
}

.recommended-pricing {
  .pricing-tips {
    margin-top: 5px;
    color: #909399;
  }
}

.profit-analysis {
  background: #f8f9fa;
  padding: 15px;
  border-radius: 4px;
  border-left: 4px solid #409eff;

  p {
    margin: 8px 0;
    font-size: 14px;
  }
}

// 表格样式优化
::v-deep .el-table {
  .el-table__body-wrapper {
    .el-table__row {
      &:hover {
        background-color: #f5f7fa;
      }
    }
  }
}

// 响应式设计
@media (max-width: 768px) {
  .filter-container {
    .filter-item {
      margin-bottom: 10px;
      width: 100%;
    }
  }

  .stat-card {
    margin-bottom: 15px;
  }
}
</style>
