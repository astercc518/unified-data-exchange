# Vue Element Admin 项目备份信息

## 项目基本信息
- **项目名称**: vue-element-admin
- **项目版本**: 4.4.0
- **备份时间**: 2025-10-11 12:19:20
- **备份目录**: backup_20251011_121920
- **操作系统**: Linux SERVER-autocrack 3.10.0-1160.119.1.el7.x86_64 #1 SMP Tue Jun 4 14:43:51 UTC 2024 x86_64 x86_64 x86_64 GNU/Linux

## 环境信息
- **Node.js版本**: v16.20.2
- **NPM版本**: 8.19.4
- **Git版本**: git version 1.8.3.1

## 项目结构
```
.
./.git
./.git/refs
./.git/branches
./.git/hooks
./.git/info
./.git/objects
./.git/logs
./.github
./.github/ISSUE_TEMPLATE
./build
./mock
./mock/role
./plop-templates
./plop-templates/component
./plop-templates/store
./plop-templates/view
./public
./src
./src/api
```

## 依赖信息
详见 package.json 文件

## 自定义功能特性
1. **数据上传功能** - 支持文件上传和数据类型自定义
2. **资源中心** - 数据展示和购买功能
3. **数据列表管理** - 完整的增删改查和定价功能
4. **用户管理** - 多角色用户系统
5. **国际化支持** - 中英文界面切换
6. **响应式设计** - 支持移动端和桌面端

## 数据存储
- 使用 localStorage 进行前端数据持久化
- 支持数据实时同步和更新
- 按时效性分类数据存储（3天内、30天内、30天以上）

## 部署说明
请参考 DEPLOYMENT.md 文件进行部署

## 联系信息
- 备份创建者: AI Assistant
- 备份日期: 2025-10-11
