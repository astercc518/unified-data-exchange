<template>
  <div class="app-container">
    <el-card v-loading="loading">
      <div slot="header" class="clearfix">
        <span>{{ $t('user.edit') }} - {{ userForm.customerName || userForm.loginAccount }}</span>
        <el-button
          style="float: right; padding: 3px 0"
          type="text"
          @click="goBack"
        >
          {{ $t('common.back') }}
        </el-button>
      </div>

      <el-form
        ref="userForm"
        :model="userForm"
        :rules="rules"
        label-width="120px"
        class="user-form"
      >
        <!-- 基本信息 -->
        <el-divider content-position="left">{{ $t('user.basicInfo') }}</el-divider>

        <el-row :gutter="20">
          <el-col :span="12">
            <el-form-item :label="$t('user.agentName')" prop="agentId">
              <el-select
                v-model="userForm.agentId"
                :placeholder="$t('user.pleaseSelectAgent')"
                style="width: 100%"
                filterable
              >
                <el-option
                  v-for="agent in agentOptions"
                  :key="agent.value"
                  :label="agent.label"
                  :value="agent.value"
                />
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item :label="$t('user.customerName')" prop="customerName">
              <el-input
                v-model="userForm.customerName"
                :placeholder="$t('user.pleaseEnterCustomerName')"
              />
            </el-form-item>
          </el-col>
        </el-row>

        <el-row :gutter="20">
          <el-col :span="12">
            <el-form-item :label="$t('user.loginAccount')" prop="loginAccount">
              <el-input
                v-model="userForm.loginAccount"
                :placeholder="$t('user.pleaseEnterLoginAccount')"
                disabled
              />
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item :label="$t('user.loginPassword')" prop="loginPassword">
              <el-input
                v-model="userForm.loginPassword"
                type="password"
                :placeholder="$t('user.pleaseEnterLoginPassword')"
                show-password
                clearable
              />
              <div class="field-note">留空则不修改密码</div>
            </el-form-item>
          </el-col>
        </el-row>

        <el-row :gutter="20">
          <el-col :span="12">
            <el-form-item :label="$t('user.salePriceRate')" prop="salePriceRate">
              <el-input-number
                v-model="userForm.salePriceRate"
                :placeholder="$t('user.pleaseEnterSalePriceRate')"
                :precision="2"
                :min="0"
                :step="0.1"
                style="width: 100%"
              />
              <div class="field-note">{{ $t('user.salePriceRateNote') }}</div>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item :label="$t('user.email')" prop="email">
              <el-input
                v-model="userForm.email"
                :placeholder="$t('user.pleaseEnterEmail')"
              />
            </el-form-item>
          </el-col>
        </el-row>

        <!-- 账户信息 -->
        <el-divider content-position="left">{{ $t('user.accountInfo') }}</el-divider>

        <el-row :gutter="20">
          <el-col :span="12">
            <el-form-item :label="$t('user.accountBalance')" prop="accountBalance">
              <el-input-number
                v-model="userForm.accountBalance"
                :placeholder="$t('user.accountBalance')"
                :precision="5"
                :min="0"
                :step="1"
                style="width: 100%"
              />
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item :label="$t('user.overdraftAmount')" prop="overdraftAmount">
              <el-input-number
                v-model="userForm.overdraftAmount"
                :placeholder="$t('user.overdraftAmount')"
                :precision="5"
                :min="0"
                :step="1"
                style="width: 100%"
              />
            </el-form-item>
          </el-col>
        </el-row>

        <!-- 其他信息 -->
        <el-divider content-position="left">{{ $t('user.contactInfo') }}</el-divider>

        <el-row :gutter="20">
          <el-col :span="12">
            <el-form-item :label="$t('user.status')" prop="status">
              <el-radio-group v-model="userForm.status">
                <el-radio :label="1">{{ $t('user.active') }}</el-radio>
                <el-radio :label="0">{{ $t('user.inactive') }}</el-radio>
              </el-radio-group>
            </el-form-item>
          </el-col>
        </el-row>

        <el-form-item :label="$t('user.remark')" prop="remark">
          <el-input
            v-model="userForm.remark"
            :placeholder="$t('user.remark')"
            type="textarea"
            :rows="3"
          />
        </el-form-item>

        <!-- 操作按钮 -->
        <el-form-item>
          <el-button
            type="primary"
            :loading="submitLoading"
            @click="submitForm"
          >
            {{ $t('common.save') }}
          </el-button>
          <el-button
            type="warning"
            @click="resetPassword"
          >
            {{ $t('user.resetPassword') }}
          </el-button>
          <el-button @click="resetForm">
            {{ $t('common.reset') }}
          </el-button>
          <el-button @click="goBack">
            {{ $t('common.cancel') }}
          </el-button>
        </el-form-item>
      </el-form>
    </el-card>
  </div>
</template>

<script>
import { parseTime } from '@/utils'
import i18nMixin from '@/mixins/i18n'

export default {
  name: 'EditUser',
  filters: {
    parseTime
  },
  mixins: [i18nMixin],
  data() {
    // 登录账号验证
    const validateLoginAccount = (rule, value, callback) => {
      if (!value) {
        callback(new Error(this.$t('user.pleaseEnterLoginAccount')))
      } else if (value.length < 3) {
        callback(new Error('登录账号至少3个字符'))
      } else {
        callback()
      }
    }

    // 密码验证（编辑模式下可选）
    const validatePassword = (rule, value, callback) => {
      // 编辑模式下，如果密码为空或未定义则不验证（表示不修改密码）
      if (!value || value.trim() === '') {
        callback() // 允许为空
        return
      }
      if (value.length < 6) {
        callback(new Error('密码至少6个字符'))
      } else {
        callback()
      }
    }

    // 邮箱验证
    const validateEmail = (rule, value, callback) => {
      if (!value) {
        callback(new Error(this.$t('user.pleaseEnterEmail')))
      } else {
        const emailReg = /^[a-zA-Z0-9_-]+@[a-zA-Z0-9_-]+(\.[a-zA-Z0-9_-]+)+$/
        if (!emailReg.test(value)) {
          callback(new Error(this.$t('user.invalidEmail')))
        } else {
          callback()
        }
      }
    }

    return {
      loading: false,
      userForm: {
        id: '',
        agentId: '',
        customerName: '',
        loginAccount: '',
        loginPassword: '',
        salePriceRate: 1,
        accountBalance: 0,
        overdraftAmount: 0,
        email: '',
        status: 1,
        remark: '',
        createTime: null
      },
      agentOptions: [],
      rules: {
        agentId: [{ required: true, message: this.$t('user.pleaseSelectAgent'), trigger: 'change' }],
        customerName: [{ required: true, message: this.$t('user.pleaseEnterCustomerName'), trigger: 'blur' }],
        loginAccount: [{ required: true, validator: validateLoginAccount, trigger: 'blur' }],
        loginPassword: [{ validator: validatePassword, trigger: 'blur' }],
        salePriceRate: [{ required: false, message: this.$t('user.pleaseEnterSalePriceRate'), trigger: 'blur' }],
        email: [{ required: true, validator: validateEmail, trigger: 'blur' }]
      },
      submitLoading: false
    }
  },
  created() {
    const id = this.$route.params && this.$route.params.id
    this.fetchData(id)
    this.loadAgents()
  },
  methods: {
    // 加载代理列表
    loadAgents() {
      const savedAgents = localStorage.getItem('agentList')
      if (savedAgents) {
        try {
          const agents = JSON.parse(savedAgents)
          // 只显示激活状态的代理
          this.agentOptions = agents
            .filter(agent => agent.status === 1)
            .map(agent => ({
              value: String(agent.id),
              label: agent.agentName
            }))
        } catch (e) {
          console.error('加载代理数据失败:', e)
          this.agentOptions = []
        }
      } else {
        this.agentOptions = []
      }
    },
    fetchData(id) {
      this.loading = true
      // 从localStorage获取用户数据
      const savedUsers = localStorage.getItem('userList')
      if (savedUsers) {
        try {
          const users = JSON.parse(savedUsers)
          const user = users.find(u => u.id === parseInt(id))
          if (user) {
            this.userForm = { ...user }
          }
        } catch (e) {
          console.error('解析用户数据失败:', e)
        }
      }
      this.loading = false
    },
    submitForm() {
      this.$refs.userForm.validate((valid) => {
        if (valid) {
          this.submitLoading = true

          // 更新localStorage中的用户数据
          const savedUsers = localStorage.getItem('userList')
          if (savedUsers) {
            try {
              const users = JSON.parse(savedUsers)
              const userIndex = users.findIndex(u => u.id === this.userForm.id)
              if (userIndex !== -1) {
                // 查找代理名称
                const selectedAgent = this.agentOptions.find(agent => agent.value === this.userForm.agentId)
                const agentName = selectedAgent ? selectedAgent.label : ''

                // 准备更新的用户数据
                const updatedUser = {
                  ...this.userForm,
                  agentName: agentName
                }

                // 如果密码为空或只包含空格，则保持原密码不变
                if (!this.userForm.loginPassword || this.userForm.loginPassword.trim() === '') {
                  updatedUser.loginPassword = users[userIndex].loginPassword
                }

                // 更新用户数据
                users[userIndex] = updatedUser

                localStorage.setItem('userList', JSON.stringify(users))

                // 更新代理绑定用户数
                this.updateAgentBindUsers(users)
              }
            } catch (e) {
              console.error('更新用户数据失败:', e)
            }
          }

          setTimeout(() => {
            this.$message({
              type: 'success',
              message: this.$t('user.updateSuccess')
            })
            this.submitLoading = false
            this.$router.push('/user/customer-list')
          }, 800)
        } else {
          return false
        }
      })
    },
    // 更新代理绑定用户数
    updateAgentBindUsers(users) {
      const savedAgents = localStorage.getItem('agentList')
      if (savedAgents) {
        try {
          const agents = JSON.parse(savedAgents)
          agents.forEach(agent => {
            const bindUsersCount = users.filter(u => String(u.agentId) === String(agent.id)).length
            agent.bindUsers = bindUsersCount
          })
          localStorage.setItem('agentList', JSON.stringify(agents))
        } catch (e) {
          console.error('更新代理绑定用户数失败:', e)
        }
      }
    },
    resetForm() {
      this.$refs.userForm.resetFields()
    },
    resetPassword() {
      this.$confirm('确认重置该用户的密码？', this.$t('common.warning'), {
        confirmButtonText: this.$t('common.confirm'),
        cancelButtonText: this.$t('common.cancel'),
        type: 'warning'
      }).then(() => {
        // 生成新密码
        const newPassword = Math.random().toString(36).slice(-8)
        this.userForm.loginPassword = newPassword

        this.$alert(`新密码: ${newPassword}`, '密码重置成功', {
          confirmButtonText: '确定',
          type: 'success'
        })
      }).catch(() => {})
    },
    goBack() {
      this.$router.go(-1)
    }
  }
}
</script>

<style lang="scss" scoped>
.user-form {
  max-width: 900px;
  margin: 0 auto;
}

.field-note {
  font-size: 12px;
  color: #909399;
  margin-top: 5px;
}
</style>
