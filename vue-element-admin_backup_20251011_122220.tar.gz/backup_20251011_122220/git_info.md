# Git 仓库信息

## 当前分支
```
无法获取当前分支
```

## 最后提交
```
6858a9a docs: update sponsor (花裤衩, 12 months ago)
```

## 仓库状态
```
 M .env.development
 M mock/mock-server.js
 M src/directive/waves/waves.css
 M src/layout/components/Sidebar/Item.vue
 M src/layout/components/Sidebar/index.vue
 M src/main.js
 M src/permission.js
 M src/router/index.js
 M src/router/modules/charts.js
 M src/router/modules/components.js
 M src/router/modules/nested.js
 M src/router/modules/table.js
 M src/settings.js
 M src/store/getters.js
 M src/store/modules/app.js
 M src/store/modules/user.js
 M src/styles/index.scss
 M src/utils/get-page-title.js
 M src/utils/validate.js
 M src/views/dashboard/admin/index.vue
 M src/views/dashboard/index.vue
 M src/views/login/index.vue
 M vue.config.js
?? COUNTRY-SELECTOR-UPDATE.md
?? DATA-TYPE-CUSTOM-REMARK-FEATURE.md
?? DATA-TYPE-FEATURE.md
?? DEPLOYMENT.md
?? PROJECT_COMPLETION_REPORT.md
?? PROJECT_GUIDE.md
?? TEST-RESULTS.md
?? backup.sh
?? backup_20251011_122220/
?? country-selector-test.html
?? data-consistency-fix.html
?? data-library-test.html
?? data-sync-fix-verification.html
?? data-type-test.html
?? database-rename-verification.html
?? debug-data-sync.html
?? deploy.sh
?? resource-country-search-test.html
?? src/api/order.js
?? src/components/ErrorBoundary.vue
?? src/components/LangSelect/
?? src/data/
?? src/icons/svg/database.svg
?? src/icons/svg/server.svg
?? src/lang/
?? src/mixins/
?? src/router/index_new.js
?? src/styles/optimization.scss
?? src/utils/i18n.js
?? src/utils/performance.js
?? src/utils/system-utils.js
?? src/views/agent/
?? src/views/dashboard/admin/components/DataDistributionChart.vue
?? src/views/dashboard/admin/components/DataPlatformPanelGroup.vue
?? src/views/dashboard/admin/components/SystemHealthCard.vue
?? src/views/dashboard/admin/components/TopAgentsCard.vue
?? src/views/dashboard/agent.vue
?? src/views/dashboard/customer.vue
?? src/views/data/
?? src/views/feedback/
?? src/views/login/lang.js
?? src/views/order/
?? src/views/recharge/
?? src/views/resource/
?? src/views/settlement/
?? src/views/user/
?? start.sh
?? system-test.html
?? system-test.js
?? test-order-data.js
?? test-order-page.html
?? test-upload-usa-data.js
?? tests/unit/views/
?? usa-data-test.html
?? vue-element-admin_backup_20251011_121920.tar.gz
?? vue-element-admin_backup_20251011_121920.zip
?? "\347\263\273\347\273\237\346\265\213\350\257\225\346\212\245\345\221\212.md"
```

## 远程仓库
```
origin	https://github.com/PanJiaChen/vue-element-admin.git (fetch)
origin	https://github.com/PanJiaChen/vue-element-admin.git (push)
```
