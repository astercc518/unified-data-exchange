#!/bin/bash

# Vue Element Admin 项目恢复脚本

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

print_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

print_info "开始恢复 Vue Element Admin 项目..."

# 检查Node.js环境
if ! command -v node &> /dev/null; then
    print_error "Node.js 未安装，请先安装 Node.js (版本 >= 8.9)"
    exit 1
fi

if ! command -v npm &> /dev/null; then
    print_error "NPM 未安装，请先安装 NPM"
    exit 1
fi

# 创建项目目录
TARGET_DIR=${1:-"vue-element-admin-restored"}
print_info "创建项目目录: $TARGET_DIR"

if [ -d "$TARGET_DIR" ]; then
    print_warning "目标目录已存在，请选择其他目录或删除现有目录"
    exit 1
fi

mkdir -p "$TARGET_DIR"

# 复制文件
print_info "复制项目文件..."
cp -r * "$TARGET_DIR/" 2>/dev/null || true

# 进入项目目录
cd "$TARGET_DIR"

# 安装依赖
print_info "安装项目依赖..."
npm install

print_success "项目恢复完成！"
print_info "进入项目目录: cd $TARGET_DIR"
print_info "启动开发服务器: npm run dev"
print_info "构建生产版本: npm run build:prod"
