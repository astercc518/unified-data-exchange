import { login, logout, getInfo } from '@/api/user'
import { getToken, setToken, removeToken } from '@/utils/auth'
import router, { resetRouter } from '@/router'

const state = {
  token: getToken(),
  name: '',
  avatar: '',
  introduction: '',
  roles: []
}

const mutations = {
  SET_TOKEN: (state, token) => {
    state.token = token
  },
  SET_INTRODUCTION: (state, introduction) => {
    state.introduction = introduction
  },
  SET_NAME: (state, name) => {
    state.name = name
  },
  SET_AVATAR: (state, avatar) => {
    state.avatar = avatar
  },
  SET_ROLES: (state, roles) => {
    state.roles = roles
  }
}

const actions = {
  // user login
  login({ commit }, userInfo) {
    const { username, password } = userInfo
    return new Promise((resolve, reject) => {
      // 首先尝试从localStorage验证用户
      const savedUsers = localStorage.getItem('userList')
      const savedAgents = localStorage.getItem('agentList')

      let user = null
      let userType = null

      // 检查客户数据
      if (savedUsers) {
        try {
          const users = JSON.parse(savedUsers)
          user = users.find(u =>
            u.loginAccount === username.trim() &&
            u.loginPassword === password &&
            u.status === 1 // 只允许激活的用户登录
          )
          if (user) {
            userType = 'customer'
          }
        } catch (e) {
          console.error('解析客户数据失败:', e)
        }
      }

      // 如果客户数据中没有找到，检查代理数据
      if (!user && savedAgents) {
        try {
          const agents = JSON.parse(savedAgents)
          user = agents.find(a =>
            a.loginAccount === username.trim() &&
            a.loginPassword === password &&
            a.status === 1 // 只允许激活的代理登录
          )
          if (user) {
            userType = 'agent'
          }
        } catch (e) {
          console.error('解析代理数据失败:', e)
        }
      }

      // 如果在localStorage中找到用户，直接登录
      if (user) {
        const token = `${userType}-${user.id}-${Date.now()}`
        commit('SET_TOKEN', token)
        setToken(token)

        // 存储用户信息供后续使用
        const userInfo = {
          id: user.id,
          name: userType === 'customer' ? user.customerName : user.agentName,
          loginAccount: user.loginAccount,
          email: user.email,
          type: userType,
          roles: userType === 'agent' ? ['agent'] : ['customer']
        }
        localStorage.setItem('currentUser', JSON.stringify(userInfo))

        resolve()
        return
      }

      // 如果本地没有找到，尝试后端登录（兼容系统管理员等）
      login({ username: username.trim(), password: password }).then(response => {
        const { data } = response
        commit('SET_TOKEN', data.token)
        setToken(data.token)
        resolve()
      }).catch(error => {
        // 本地和后端都没有找到用户
        reject(new Error('用户名或密码错误'))
      })
    })
  },

  // get user info
  getInfo({ commit, state }) {
    return new Promise((resolve, reject) => {
      // 首先尝试从localStorage获取用户信息
      const currentUser = localStorage.getItem('currentUser')

      if (currentUser) {
        try {
          const userData = JSON.parse(currentUser)

          // 验证token是否匹配（简单验证）
          if (state.token && state.token.includes(userData.type) && state.token.includes(userData.id.toString())) {
            const { roles, name } = userData

            // roles must be a non-empty array
            if (!roles || roles.length <= 0) {
              reject('getInfo: roles must be a non-null array!')
              return
            }

            commit('SET_ROLES', roles)
            commit('SET_NAME', name)
            commit('SET_AVATAR', 'https://wpimg.wallstcn.com/f778738c-e4f8-4870-b634-56703b4acafe.gif')
            commit('SET_INTRODUCTION', `${userData.type === 'customer' ? '客户' : '代理'}: ${name}`)

            resolve(userData)
            return
          }
        } catch (e) {
          console.error('解析用户信息失败:', e)
        }
      }

      // 如果本地没有用户信息，尝试后端获取
      getInfo(state.token).then(response => {
        const { data } = response

        if (!data) {
          reject('Verification failed, please Login again.')
        }

        const { roles, name, avatar, introduction } = data

        // roles must be a non-empty array
        if (!roles || roles.length <= 0) {
          reject('getInfo: roles must be a non-null array!')
        }

        commit('SET_ROLES', roles)
        commit('SET_NAME', name)
        commit('SET_AVATAR', avatar)
        commit('SET_INTRODUCTION', introduction)
        resolve(data)
      }).catch(error => {
        reject(error)
      })
    })
  },

  // user logout
  logout({ commit, state, dispatch }) {
    return new Promise((resolve, reject) => {
      // 清理localStorage中的用户信息
      localStorage.removeItem('currentUser')

      logout(state.token).then(() => {
        commit('SET_TOKEN', '')
        commit('SET_ROLES', [])
        removeToken()
        resetRouter()

        // reset visited views and cached views
        // to fixed https://github.com/PanJiaChen/vue-element-admin/issues/2485
        dispatch('tagsView/delAllViews', null, { root: true })

        resolve()
      }).catch(error => {
        // 即使后端登出失败，也要清理本地状态
        commit('SET_TOKEN', '')
        commit('SET_ROLES', [])
        removeToken()
        resetRouter()
        dispatch('tagsView/delAllViews', null, { root: true })
        resolve()
      })
    })
  },

  // remove token
  resetToken({ commit }) {
    return new Promise(resolve => {
      commit('SET_TOKEN', '')
      commit('SET_ROLES', [])
      removeToken()
      // 清理localStorage中的用户信息
      localStorage.removeItem('currentUser')
      resolve()
    })
  },

  // dynamically modify permissions
  async changeRoles({ commit, dispatch }, role) {
    const token = role + '-token'

    commit('SET_TOKEN', token)
    setToken(token)

    const { roles } = await dispatch('getInfo')

    resetRouter()

    // generate accessible routes map based on roles
    const accessRoutes = await dispatch('permission/generateRoutes', roles, { root: true })
    // dynamically add accessible routes
    router.addRoutes(accessRoutes)

    // reset visited views and cached views
    dispatch('tagsView/delAllViews', null, { root: true })
  }
}

export default {
  namespaced: true,
  state,
  mutations,
  actions
}
