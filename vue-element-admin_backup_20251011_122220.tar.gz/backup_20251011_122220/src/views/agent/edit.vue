<template>
  <div class="app-container">
    <el-card>
      <div slot="header" class="clearfix">
        <span>{{ $t('agent.edit') }} - {{ agentForm.agentName }}</span>
        <el-button
          style="float: right; padding: 3px 0"
          type="text"
          @click="goBack"
        >
          {{ $t('common.back') }}
        </el-button>
      </div>

      <el-form
        ref="agentForm"
        :model="agentForm"
        :rules="rules"
        label-width="120px"
        class="agent-form"
      >
        <el-divider content-position="left">{{ $t('user.basicInfo') }}</el-divider>

        <el-row :gutter="20">
          <el-col :span="12">
            <el-form-item :label="$t('agent.agentCode')" prop="agentCode">
              <el-input
                v-model="agentForm.agentCode"
                :placeholder="$t('agent.pleaseEnterAgentCode')"
                disabled
              />
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item :label="$t('agent.agentName')" prop="agentName">
              <el-input
                v-model="agentForm.agentName"
                :placeholder="$t('agent.pleaseEnterAgentName')"
              />
            </el-form-item>
          </el-col>
        </el-row>

        <el-row :gutter="20">
          <el-col :span="12">
            <el-form-item :label="$t('agent.commission')" prop="commission">
              <el-input-number
                v-model="agentForm.commission"
                :min="0"
                :max="100"
                :precision="2"
                style="width: 100%"
                controls-position="right"
              />
              <span style="margin-left: 10px;">%</span>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item :label="$t('user.status')" prop="status">
              <el-radio-group v-model="agentForm.status">
                <el-radio :label="1">{{ $t('user.active') }}</el-radio>
                <el-radio :label="0">{{ $t('user.inactive') }}</el-radio>
              </el-radio-group>
            </el-form-item>
          </el-col>
        </el-row>

        <el-divider content-position="left">{{ $t('user.contactInfo') }}</el-divider>

        <el-row :gutter="20">
          <el-col :span="12">
            <el-form-item :label="$t('user.email')" prop="email">
              <el-input
                v-model="agentForm.email"
                :placeholder="$t('user.pleaseEnterEmail')"
              />
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item :label="$t('user.phone')" prop="phone">
              <el-input
                v-model="agentForm.phone"
                :placeholder="$t('user.pleaseEnterPhone')"
              />
            </el-form-item>
          </el-col>
        </el-row>

        <el-form-item :label="$t('user.remark')" prop="remark">
          <el-input
            v-model="agentForm.remark"
            :placeholder="$t('user.remark')"
            type="textarea"
            :rows="3"
          />
        </el-form-item>

        <el-form-item>
          <el-button
            type="primary"
            :loading="submitLoading"
            @click="submitForm"
          >
            {{ $t('common.save') }}
          </el-button>
          <el-button @click="resetForm">
            {{ $t('common.reset') }}
          </el-button>
          <el-button @click="goBack">
            {{ $t('common.cancel') }}
          </el-button>
        </el-form-item>
      </el-form>
    </el-card>
  </div>
</template>

<script>
import i18nMixin from '@/mixins/i18n'

export default {
  name: 'EditAgent',
  mixins: [i18nMixin],
  data() {
    return {
      agentForm: {
        id: '',
        agentCode: '',
        agentName: '',
        commission: 10.0,
        status: 1,
        email: '',
        phone: '',
        remark: ''
      },
      rules: {
        agentName: [{ required: true, message: this.$t('agent.pleaseEnterAgentName'), trigger: 'blur' }],
        commission: [{ required: true, message: this.$t('agent.pleaseEnterCommission'), trigger: 'blur' }],
        email: [{ required: true, message: this.$t('user.pleaseEnterEmail'), trigger: 'blur' }]
      },
      submitLoading: false
    }
  },
  created() {
    const id = this.$route.params && this.$route.params.id
    this.fetchData(id)
  },
  methods: {
    fetchData(id) {
      // 模拟获取代理数据
      this.agentForm = {
        id: id,
        agentCode: 'AGENT001',
        agentName: '一级代理商A',
        commission: 15.5,
        status: 1,
        email: 'agent001@example.com',
        phone: '13800138001',
        remark: '优质代理商'
      }
    },
    submitForm() {
      this.$refs.agentForm.validate((valid) => {
        if (valid) {
          this.submitLoading = true
          setTimeout(() => {
            this.$message({
              type: 'success',
              message: this.$t('agent.updateAgentSuccess')
            })
            this.submitLoading = false
            this.$router.push('/agent/list')
          }, 1500)
        }
      })
    },
    resetForm() {
      this.$refs.agentForm.resetFields()
    },
    goBack() {
      this.$router.go(-1)
    }
  }
}
</script>

<style lang="scss" scoped>
.agent-form {
  max-width: 800px;
  margin: 0 auto;
}
</style>
