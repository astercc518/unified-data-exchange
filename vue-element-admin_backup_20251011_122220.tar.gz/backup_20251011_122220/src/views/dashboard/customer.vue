<template>
  <div class="dashboard-container">
    <div class="dashboard-text">
      <h1>{{ welcomeMessage }}</h1>
      <p>{{ $t('dashboard.customerDescription') }}</p>
    </div>

    <!-- 客户统计卡片 -->
    <el-row :gutter="40" class="panel-group">
      <el-col :xs="12" :sm="12" :lg="6" class="card-panel-col">
        <div class="card-panel">
          <div class="card-panel-icon-wrapper icon-money">
            <svg-icon icon-class="money" class-name="card-panel-icon" />
          </div>
          <div class="card-panel-description">
            <div class="card-panel-text">{{ $t('dashboard.accountBalance') }}</div>
            <div class="card-panel-num">¥{{ customerStats.accountBalance }}</div>
          </div>
        </div>
      </el-col>

      <el-col :xs="12" :sm="12" :lg="6" class="card-panel-col">
        <div class="card-panel">
          <div class="card-panel-icon-wrapper icon-shopping">
            <svg-icon icon-class="shopping" class-name="card-panel-icon" />
          </div>
          <div class="card-panel-description">
            <div class="card-panel-text">{{ $t('dashboard.totalOrders') }}</div>
            <count-to :start-val="0" :end-val="customerStats.totalOrders" :duration="2600" class="card-panel-num" />
          </div>
        </div>
      </el-col>

      <el-col :xs="12" :sm="12" :lg="6" class="card-panel-col">
        <div class="card-panel">
          <div class="card-panel-icon-wrapper icon-data">
            <svg-icon icon-class="documentation" class-name="card-panel-icon" />
          </div>
          <div class="card-panel-description">
            <div class="card-panel-text">{{ $t('dashboard.totalData') }}</div>
            <count-to :start-val="0" :end-val="customerStats.totalData" :duration="3000" class="card-panel-num" />
          </div>
        </div>
      </el-col>

      <el-col :xs="12" :sm="12" :lg="6" class="card-panel-col">
        <div class="card-panel">
          <div class="card-panel-icon-wrapper icon-message">
            <svg-icon icon-class="message" class-name="card-panel-icon" />
          </div>
          <div class="card-panel-description">
            <div class="card-panel-text">{{ $t('dashboard.feedbackCount') }}</div>
            <count-to :start-val="0" :end-val="customerStats.feedbackCount" :duration="2800" class="card-panel-num" />
          </div>
        </div>
      </el-col>
    </el-row>

    <!-- 客户功能快捷入口 -->
    <el-row :gutter="20" style="margin-top: 30px;">
      <el-col :span="12">
        <el-card class="box-card">
          <div slot="header" class="clearfix">
            <span>{{ $t('dashboard.customerActions') }}</span>
          </div>
          <div class="action-buttons">
            <el-button type="primary" icon="el-icon-shopping-cart-2" @click="goToResource">
              {{ $t('dashboard.buyData') }}
            </el-button>
            <el-button type="success" icon="el-icon-view" @click="goToOrders">
              {{ $t('dashboard.viewOrders') }}
            </el-button>
            <el-button type="warning" icon="el-icon-message" @click="goToFeedback">
              {{ $t('dashboard.submitFeedback') }}
            </el-button>
          </div>
        </el-card>
      </el-col>

      <el-col :span="12">
        <el-card class="box-card">
          <div slot="header" class="clearfix">
            <span>{{ $t('dashboard.recentActivity') }}</span>
          </div>
          <div class="activity-list">
            <div v-for="activity in recentActivities" :key="activity.id" class="activity-item">
              <i :class="activity.icon" :style="{ color: activity.color }" />
              <span class="activity-text">{{ activity.text }}</span>
              <span class="activity-time">{{ activity.time }}</span>
            </div>
          </div>
        </el-card>
      </el-col>
    </el-row>

  </div>
</template>

<script>
import CountTo from 'vue-count-to'

export default {
  name: 'CustomerDashboard',
  components: {
    CountTo
  },
  data() {
    return {
      welcomeMessage: this.$t('dashboard.customerWelcome'), // 默认欢迎信息
      customerStats: {
        accountBalance: '0.00000',
        totalOrders: 0,
        totalData: 0,
        feedbackCount: 0
      },
      recentActivities: [
        {
          id: 1,
          icon: 'el-icon-shopping-cart-2',
          color: '#409EFF',
          text: '购买数据',
          time: '3小时前'
        },
        {
          id: 2,
          icon: 'el-icon-wallet',
          color: '#67C23A',
          text: '账户充值',
          time: '1天前'
        },
        {
          id: 3,
          icon: 'el-icon-download',
          color: '#E6A23C',
          text: '数据下载',
          time: '2天前'
        },
        {
          id: 4,
          icon: 'el-icon-message',
          color: '#F56C6C',
          text: '提交反馈',
          time: '3天前'
        }
      ]
    }
  },
  created() {
    this.loadCustomerStats()
  },
  methods: {
    loadCustomerStats() {
      // 从localStorage获取当前客户信息
      const currentUser = localStorage.getItem('currentUser')
      if (currentUser) {
        try {
          const userData = JSON.parse(currentUser)
          if (userData.type === 'customer') {
            // 设置个性化欢迎信息
            this.setWelcomeMessage(userData)
            this.loadCustomerData(userData.id)
          }
        } catch (e) {
          console.error('解析用户数据失败:', e)
        }
      }
    },
    setWelcomeMessage(userData) {
      // 优先使用loginAccount（平台登录账号），其次使用customerName或username
      const displayName = userData.loginAccount || userData.customerName || userData.username || '客户'
      this.welcomeMessage = `欢迎尊敬的${displayName}客户`
    },
    loadCustomerData(customerId) {
      // 获取客户数据
      const savedUsers = localStorage.getItem('userList')
      if (savedUsers) {
        try {
          const users = JSON.parse(savedUsers)
          const customer = users.find(u => u.id === customerId)
          if (customer) {
            this.customerStats.accountBalance = parseFloat(customer.accountBalance || 0).toFixed(5)
          }
        } catch (e) {
          console.error('加载客户数据失败:', e)
        }
      }

      // 加载实际的统计数据
      this.loadRealStats(customerId)

      // 加载最近活动记录
      this.loadRecentActivities(customerId)
    },

    // 加载真实的统计数据
    loadRealStats(customerId) {
      // 加载订单数量
      this.loadOrderStats(customerId)

      // 加载数据购买量
      this.loadDataStats(customerId)

      // 加载反馈数量（暂时使用模拟数据）
      this.customerStats.feedbackCount = 0 // 待反馈功能实现后更新
    },

    // 加载订单统计
    loadOrderStats(customerId) {
      const savedOrders = localStorage.getItem('orderList')
      if (savedOrders) {
        try {
          const orders = JSON.parse(savedOrders)
          // 统计该客户的订单数量
          this.customerStats.totalOrders = orders.filter(order => order.customerId === customerId).length
        } catch (e) {
          console.error('加载订单数据失败:', e)
          this.customerStats.totalOrders = 0
        }
      } else {
        this.customerStats.totalOrders = 0
      }
    },

    // 加载数据购买量统计
    loadDataStats(customerId) {
      const savedOrders = localStorage.getItem('orderList')
      if (savedOrders) {
        try {
          const orders = JSON.parse(savedOrders)
          // 统计该客户购买的数据总量
          const customerOrders = orders.filter(order => order.customerId === customerId)
          this.customerStats.totalData = customerOrders.reduce((total, order) => {
            return total + (order.quantity || 0)
          }, 0)
        } catch (e) {
          console.error('加载数据统计失败:', e)
          this.customerStats.totalData = 0
        }
      } else {
        this.customerStats.totalData = 0
      }
    },

    // 加载最近活动记录
    loadRecentActivities(customerId) {
      const activities = []

      // 从订单记录中获取购买活动
      const savedOrders = localStorage.getItem('orderList')
      if (savedOrders) {
        try {
          const orders = JSON.parse(savedOrders)
          const customerOrders = orders
            .filter(order => order.customerId === customerId)
            .sort((a, b) => b.createTime - a.createTime)
            .slice(0, 2) // 只取最近2条

          customerOrders.forEach(order => {
            activities.push({
              id: `order_${order.id}`,
              icon: 'el-icon-shopping-cart-2',
              color: '#409EFF',
              text: `购买${order.country}数据 ${this.formatNumber(order.quantity)}条`,
              time: this.formatTime(order.createTime)
            })
          })
        } catch (e) {
          console.error('加载订单活动失败:', e)
        }
      }

      // 从充值记录中获取充值活动
      const savedRecords = localStorage.getItem('rechargeRecords')
      if (savedRecords) {
        try {
          const records = JSON.parse(savedRecords)
          const customerRecords = records
            .filter(record => record.customerId === customerId && parseFloat(record.amount) > 0)
            .sort((a, b) => b.createTime - a.createTime)
            .slice(0, 2) // 只取最近2条

          customerRecords.forEach(record => {
            activities.push({
              id: `recharge_${record.id}`,
              icon: 'el-icon-wallet',
              color: '#67C23A',
              text: `账户充值 ${record.amount}U`,
              time: this.formatTime(record.createTime)
            })
          })
        } catch (e) {
          console.error('加载充值活动失败:', e)
        }
      }

      // 按时间排序并只保留最近4条
      this.recentActivities = activities
        .sort((a, b) => {
          // 解析时间字符串进行排序
          const timeA = this.parseTimeString(a.time)
          const timeB = this.parseTimeString(b.time)
          return timeB - timeA
        })
        .slice(0, 4)

      // 如果没有活动记录，显示默认提示
      if (this.recentActivities.length === 0) {
        this.recentActivities = [{
          id: 'no_activity',
          icon: 'el-icon-info',
          color: '#909399',
          text: '暂无活动记录',
          time: ''
        }]
      }
    },

    // 格式化时间
    formatTime(timestamp) {
      const now = Date.now()
      const diff = now - timestamp

      const minute = 60 * 1000
      const hour = minute * 60
      const day = hour * 24

      if (diff < minute) {
        return '刚刚'
      } else if (diff < hour) {
        return Math.floor(diff / minute) + '分钟前'
      } else if (diff < day) {
        return Math.floor(diff / hour) + '小时前'
      } else {
        return Math.floor(diff / day) + '天前'
      }
    },

    // 解析时间字符串（用于排序）
    parseTimeString(timeStr) {
      const now = Date.now()
      if (timeStr === '刚刚') return now
      if (timeStr.includes('分钟前')) {
        const minutes = parseInt(timeStr)
        return now - minutes * 60 * 1000
      }
      if (timeStr.includes('小时前')) {
        const hours = parseInt(timeStr)
        return now - hours * 60 * 60 * 1000
      }
      if (timeStr.includes('天前')) {
        const days = parseInt(timeStr)
        return now - days * 24 * 60 * 60 * 1000
      }
      return 0
    },

    // 格式化数字
    formatNumber(num) {
      return num.toLocaleString()
    },
    goToResource() {
      this.$router.push('/resource/center')
    },
    goToOrders() {
      this.$router.push('/order/list')
    },
    goToFeedback() {
      this.$router.push('/feedback/create')
    }
  }
}
</script>

<style lang="scss" scoped>
.dashboard-container {
  padding: 32px;
  background-color: rgb(240, 242, 245);
  position: relative;
}

.dashboard-text {
  text-align: center;
  margin-bottom: 40px;

  h1 {
    font-size: 28px;
    color: #2c3e50;
    margin-bottom: 10px;
  }

  p {
    font-size: 16px;
    color: #7f8c8d;
  }
}

.panel-group {
  margin-top: 18px;

  .card-panel-col {
    margin-bottom: 32px;
  }

  .card-panel {
    height: 108px;
    cursor: pointer;
    font-size: 12px;
    position: relative;
    overflow: hidden;
    color: #666;
    background: #fff;
    box-shadow: 4px 4px 40px rgba(0, 0, 0, .05);
    border-color: rgba(0, 0, 0, .05);
    border-radius: 4px;

    &:hover {
      .card-panel-icon-wrapper {
        color: #fff;
      }

      .icon-money {
        background: #40c9c6;
      }

      .icon-shopping {
        background: #36a3f7;
      }

      .icon-data {
        background: #f4516c;
      }

      .icon-message {
        background: #34bfa3;
      }
    }

    .icon-money {
      color: #40c9c6;
    }

    .icon-shopping {
      color: #36a3f7;
    }

    .icon-data {
      color: #f4516c;
    }

    .icon-message {
      color: #34bfa3;
    }

    .card-panel-icon-wrapper {
      float: left;
      margin: 14px 0 0 14px;
      padding: 16px;
      transition: all 0.38s ease-out;
      border-radius: 6px;
    }

    .card-panel-icon {
      float: left;
      font-size: 48px;
    }

    .card-panel-description {
      float: right;
      font-weight: bold;
      margin: 26px;
      margin-left: 0px;

      .card-panel-text {
        line-height: 18px;
        color: rgba(0, 0, 0, 0.45);
        font-size: 16px;
        margin-bottom: 12px;
      }

      .card-panel-num {
        font-size: 20px;
      }
    }
  }
}

.box-card {
  .action-buttons {
    display: flex;
    flex-direction: column;
    gap: 10px;
  }

  .activity-list {
    .activity-item {
      display: flex;
      align-items: center;
      padding: 8px 0;
      border-bottom: 1px solid #f0f0f0;

      &:last-child {
        border-bottom: none;
      }

      i {
        margin-right: 12px;
        font-size: 16px;
      }

      .activity-text {
        flex: 1;
        color: #606266;
      }

      .activity-time {
        color: #909399;
        font-size: 12px;
      }
    }
  }
}

</style>
