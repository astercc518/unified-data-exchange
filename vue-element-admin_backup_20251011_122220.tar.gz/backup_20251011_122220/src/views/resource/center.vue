<template>
  <div class="app-container">
    <!-- 用户余额卡片 -->
    <el-row :gutter="20" style="margin-bottom: 20px;">
      <el-col :span="8">
        <el-card class="balance-card">
          <div class="balance-content">
            <div class="balance-number">{{ userBalance }}</div>
            <div class="balance-label">账户余额 (U)</div>
          </div>
          <i class="el-icon-wallet balance-icon" />
        </el-card>
      </el-col>
      <el-col :span="8">
        <el-card class="balance-card">
          <div class="balance-content">
            <div class="balance-number">{{ formatNumber(totalPurchased) }}</div>
            <div class="balance-label">已购买数据</div>
          </div>
          <i class="el-icon-data-line balance-icon" />
        </el-card>
      </el-col>
      <el-col :span="8">
        <el-card class="balance-card">
          <div class="balance-content">
            <div class="balance-number">{{ totalSpent }}</div>
            <div class="balance-label">累计消费 (U)</div>
          </div>
          <i class="el-icon-money balance-icon" />
        </el-card>
      </el-col>
    </el-row>

    <!-- 筛选条件 -->
    <el-card style="margin-bottom: 20px;">
      <div class="filter-container">
        <el-select
          v-model="listQuery.country"
          :placeholder="$t('data.selectCountry')"
          filterable
          remote
          reserve-keyword
          :remote-method="searchCountries"
          :loading="countryLoading"
          clearable
          style="width: 250px"
          class="filter-item"
          @focus="initCountryOptions"
        >
          <el-option-group
            v-if="showPopularCountries"
            label="热门国家"
          >
            <el-option
              v-for="country in popularCountries"
              :key="country.code"
              :label="`${country.name} (${country.nameEn}) [${country.code}]`"
              :value="country.code"
            >
              <span style="float: left">{{ country.name }} ({{ country.nameEn }})</span>
              <span style="float: right; color: #8492a6; font-size: 13px">{{ country.code }}</span>
            </el-option>
          </el-option-group>
          <el-option
            v-for="country in filteredCountries"
            :key="country.code"
            :label="`${country.name} (${country.nameEn}) [${country.code}]`"
            :value="country.code"
          >
            <span style="float: left">{{ country.name }} ({{ country.nameEn }})</span>
            <span style="float: right; color: #8492a6; font-size: 13px">{{ country.code }}</span>
          </el-option>
        </el-select>

        <el-select
          v-model="listQuery.validity"
          :placeholder="$t('data.selectValidity')"
          clearable
          style="width: 120px"
          class="filter-item"
        >
          <el-option :label="$t('data.validityDay3')" value="3" />
          <el-option :label="$t('data.validityDay30')" value="30" />
          <el-option :label="$t('data.validityOver30')" value="30+" />
        </el-select>

        <el-input
          v-model="listQuery.source"
          :placeholder="$t('data.source')"
          style="width: 200px;"
          class="filter-item"
          @keyup.enter.native="handleFilter"
        />

        <el-button
          v-waves
          class="filter-item"
          type="primary"
          icon="el-icon-search"
          @click="handleFilter"
        >
          {{ $t('common.search') }}
        </el-button>
      </div>
    </el-card>

    <!-- 可购买数据列表 -->
    <el-card>
      <div slot="header" class="clearfix">
        <span>{{ $t('resource.available') }}</span>
      </div>

      <el-table
        :key="tableKey"
        v-loading="listLoading"
        :data="list"
        border
        fit
        highlight-current-row
        style="width: 100%;"
      >
        <el-table-column
          label="ID"
          prop="id"
          align="center"
          width="80"
        />
        <el-table-column
          :label="$t('data.country')"
          prop="country"
          width="120"
        />
        <el-table-column
          label="数据类型"
          prop="dataType"
          width="100"
        />
        <el-table-column
          :label="$t('data.validity')"
          prop="validity"
          width="100"
          align="center"
        >
          <template slot-scope="{row}">
            <el-tag :type="getValidityTagType(row.validity)">
              {{ getValidityText(row.validity) }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column
          :label="$t('data.source')"
          prop="source"
          min-width="150"
        />
        <el-table-column
          :label="$t('data.quantity')"
          prop="availableQuantity"
          width="120"
          align="center"
        >
          <template slot-scope="{row}">
            {{ formatNumber(row.availableQuantity) }}
          </template>
        </el-table-column>
        <el-table-column
          label="运营商分布"
          min-width="200"
        >
          <template slot-scope="{row}">
            <div class="operator-distribution">
              <div v-for="operator in row.operators" :key="operator.name" class="operator-item">
                <span class="operator-name">{{ operator.name }}:</span>
                <span class="operator-count">{{ formatNumber(operator.count) }}</span>
                <span class="operator-percent">({{ (operator.count / row.availableQuantity * 100).toFixed(1) }}%)</span>
              </div>
            </div>
          </template>
        </el-table-column>
        <el-table-column
          :label="$t('data.sellPrice')"
          prop="sellPrice"
          width="100"
          align="center"
        >
          <template slot-scope="{row}">
            <span class="price-highlight">{{ calculateDiscountedPrice(row.sellPrice) }} U/条</span>
          </template>
        </el-table-column>
        <el-table-column
          label="数据状态"
          width="100"
          align="center"
        >
          <template>
            <el-tag type="success">
              可购买
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column
          :label="$t('common.operation')"
          align="center"
          width="120"
          class-name="small-padding fixed-width"
        >
          <template slot-scope="{row}">
            <el-button
              type="primary"
              size="mini"
              :disabled="userBalance <= 0"
              @click="handlePurchase(row)"
            >
              购买
            </el-button>
          </template>
        </el-table-column>
      </el-table>

      <!-- 分页 -->
      <pagination
        v-show="total>0"
        :total="total"
        :page.sync="listQuery.page"
        :limit.sync="listQuery.limit"
        @pagination="getList"
      />
    </el-card>
  </div>
</template>

<script>
import Pagination from '@/components/Pagination'
import waves from '@/directive/waves'
import i18nMixin from '@/mixins/i18n'
import {
  filterCountries,
  getCountryByCode,
  getPopularCountries
} from '@/data/countries'

export default {
  name: 'ResourceCenter',
  components: { Pagination },
  directives: { waves },
  mixins: [i18nMixin],
  data() {
    return {
      tableKey: 0,
      list: [],
      total: 0,
      listLoading: true,
      listQuery: {
        page: 1,
        limit: 20,
        country: undefined,
        validity: undefined,
        source: undefined
      },
      userBalance: 1580.50,
      totalPurchased: 850000,
      totalSpent: 2420.30,
      customerSalePriceRate: 1, // 客户销售价比例
      // 国家相关数据
      countryLoading: false,
      filteredCountries: [],
      popularCountries: [],
      showPopularCountries: true,
      countrySearchKeyword: ''
    }
  },
  created() {
    this.getList()
    this.loadCustomerInfo()
    this.initCountryData()
  },
  methods: {
    getList() {
      this.listLoading = true
      console.log('🔄 资源中心开始加载数据...')

      // 从 localStorage 获取真实上传的数据
      setTimeout(() => {
        try {
          const savedDataList = localStorage.getItem('dataList')
          let dataList = []

          if (savedDataList) {
            try {
              dataList = JSON.parse(savedDataList)
              console.log('📄 从 localStorage 加载数据:', dataList.length, '条')

              // 检查数据结构
              if (dataList.length > 0) {
                const sampleData = dataList[0]
                console.log('🔍 数据结构示例:', {
                  id: sampleData.id,
                  country: sampleData.country,
                  dataType: sampleData.dataType,
                  availableQuantity: sampleData.availableQuantity,
                  uploadTime: sampleData.uploadTime
                })

                // 检查最新数据
                const now = Date.now()
                const recentData = dataList.filter(item => {
                  const uploadTime = new Date(item.uploadTime).getTime()
                  return (now - uploadTime) < 3600000 // 1小时内
                })

                if (recentData.length > 0) {
                  console.log('✅ 发现最近上传的数据:', recentData.length, '条')
                } else {
                  console.log('🕰️ 没有最近上传的数据（1小时内）')
                }
              }
            } catch (parseError) {
              console.error('❌ 解析 dataList 失败:', parseError)
              dataList = this.getDefaultData()
              console.log('🛠️ 使用默认数据:', dataList.length, '条')
            }
          } else {
            // 如果没有数据，使用默认数据
            dataList = this.getDefaultData()
            console.log('🛠️ 未找到 localStorage 数据，使用默认数据:', dataList.length, '条')
          }

          // 应用筛选条件
          const filteredList = this.applyFilters(dataList)
          console.log('🔍 筛选后数据:', filteredList.length, '条')

          // 显示筛选条件
          if (this.listQuery.country || this.listQuery.validity || this.listQuery.source) {
            console.log('🔍 当前筛选条件:', {
              country: this.listQuery.country,
              validity: this.listQuery.validity,
              source: this.listQuery.source
            })
          }

          this.list = filteredList
          this.total = filteredList.length
          this.listLoading = false

          console.log('✅ 数据加载完成，最终显示:', this.list.length, '条')
        } catch (error) {
          console.error('❌ 加载数据失败:', error)
          this.list = this.getDefaultData()
          this.total = this.list.length
          this.listLoading = false

          this.$message({
            type: 'error',
            message: '加载数据失败，显示默认数据',
            duration: 3000
          })
        }
      }, 500)
    },
    handleFilter() {
      this.listQuery.page = 1
      this.getList()
    },
    handlePurchase(row) {
      if (this.userBalance <= 0) {
        this.$message.error(this.$t('resource.insufficientBalance'))
        return
      }
      this.$router.push(`/resource/purchase/${row.id}`)
    },
    formatNumber(num) {
      return num.toLocaleString()
    },
    getValidityText(validity) {
      const validityMap = {
        '3': '3天内',
        '30': '30天内',
        '30+': '30天以上'
      }
      return validityMap[validity] || validity
    },
    getValidityTagType(validity) {
      const tagMap = {
        '3': 'danger',
        '30': 'warning',
        '30+': 'success'
      }
      return tagMap[validity]
    },
    // 加载客户信息
    loadCustomerInfo() {
      const currentUser = localStorage.getItem('currentUser')
      if (currentUser) {
        try {
          const userData = JSON.parse(currentUser)
          if (userData.type === 'customer') {
            const savedUsers = localStorage.getItem('userList')
            if (savedUsers) {
              const users = JSON.parse(savedUsers)
              const customer = users.find(u => u.id === userData.id)
              if (customer && customer.salePriceRate !== undefined) {
                this.customerSalePriceRate = customer.salePriceRate
              } else {
                this.customerSalePriceRate = 1 // 默认为1
              }
            }
          }
        } catch (e) {
          console.error('解析用户信息失败:', e)
        }
      }
    },
    // 计算销售价比例后的价格
    calculateDiscountedPrice(originalPrice) {
      if (!this.customerSalePriceRate || this.customerSalePriceRate <= 0) {
        return originalPrice
      }
      const finalPrice = originalPrice * this.customerSalePriceRate
      return finalPrice.toFixed(4)
    },

    // 获取默认数据（如果 localStorage 中没有数据）
    getDefaultData() {
      return [
        {
          id: 1,
          country: '孟加拉国',
          countryCode: 'BD',
          validity: '3',
          source: 'Grameenphone官方',
          dataType: '手机号码',
          availableQuantity: 500000,
          operators: [
            { name: 'Grameenphone', count: 150000 },
            { name: 'Robi', count: 150000 },
            { name: 'Banglalink', count: 100000 },
            { name: 'Teletalk', count: 100000 }
          ],
          sellPrice: 0.05,
          status: 'available'
        },
        {
          id: 2,
          country: '孟加拉国',
          countryCode: 'BD',
          validity: '30',
          source: '第三方采集',
          dataType: '用户资料',
          availableQuantity: 800000,
          operators: [
            { name: 'Grameenphone', count: 200000 },
            { name: 'Robi', count: 200000 },
            { name: 'Banglalink', count: 200000 },
            { name: 'Teletalk', count: 200000 }
          ],
          sellPrice: 0.04,
          status: 'available'
        },
        {
          id: 3,
          country: '印度',
          countryCode: 'IN',
          validity: '30+',
          source: '合作伙伴',
          dataType: '电话号码',
          availableQuantity: 1200000,
          operators: [
            { name: 'Airtel', count: 400000 },
            { name: 'Jio', count: 400000 },
            { name: 'Vi', count: 300000 },
            { name: 'BSNL', count: 100000 }
          ],
          sellPrice: 0.03,
          status: 'available'
        }
      ]
    },

    // 应用筛选条件
    applyFilters(dataList) {
      let filteredList = [...dataList]

      // 国家筛选
      if (this.listQuery.country) {
        filteredList = filteredList.filter(item => {
          return item.countryCode === this.listQuery.country ||
                 item.country.includes(this.listQuery.country)
        })
      }

      // 时效筛选
      if (this.listQuery.validity) {
        filteredList = filteredList.filter(item => item.validity === this.listQuery.validity)
      }

      // 数据来源筛选
      if (this.listQuery.source) {
        filteredList = filteredList.filter(item =>
          item.source.toLowerCase().includes(this.listQuery.source.toLowerCase())
        )
      }

      return filteredList
    },

    // 国家相关方法
    initCountryData() {
      // 初始化热门国家
      this.popularCountries = getPopularCountries()
      // 初始化分组国家（仅在未搜索时显示）
      this.filteredCountries = []
    },

    initCountryOptions() {
      // 焦点时初始化国家选项
      if (!this.countrySearchKeyword) {
        this.showPopularCountries = true
        this.filteredCountries = []
      }
    },

    searchCountries(keyword) {
      this.countrySearchKeyword = keyword
      this.countryLoading = true

      // 模拟异步搜索
      setTimeout(() => {
        if (keyword) {
          this.showPopularCountries = false
          this.filteredCountries = filterCountries(keyword)
        } else {
          this.showPopularCountries = true
          this.filteredCountries = []
        }
        this.countryLoading = false
      }, 300)
    },

    getCountryText(countryCode) {
      const country = getCountryByCode(countryCode)
      return country ? country.name : countryCode
    }
  }
}
</script>

<style lang="scss" scoped>
.filter-container {
  .filter-item {
    display: inline-block;
    vertical-align: middle;
    margin-right: 10px;
  }
}

.balance-card {
  position: relative;
  overflow: hidden;

  .balance-content {
    .balance-number {
      font-size: 24px;
      font-weight: bold;
      color: #409eff;
      margin-bottom: 5px;
    }

    .balance-label {
      font-size: 14px;
      color: #606266;
    }
  }

  .balance-icon {
    position: absolute;
    right: 20px;
    top: 50%;
    transform: translateY(-50%);
    font-size: 40px;
    color: #ddd;
  }
}

.operator-distribution {
  .operator-item {
    margin-bottom: 5px;

    .operator-name {
      font-weight: bold;
      margin-right: 5px;
    }

    .operator-count {
      color: #409eff;
      margin-right: 5px;
    }

    .operator-percent {
      color: #909399;
      font-size: 12px;
    }
  }
}

.price-highlight {
  color: #f56c6c;
  font-weight: bold;
  font-size: 14px;
}

.original-price {
  margin-top: 2px;

  .original-price-text {
    color: #909399;
    font-size: 11px;
    text-decoration: line-through;
  }
}

// 国家选择器样式优化
::v-deep .el-select-dropdown {
  .el-select-group__title {
    font-weight: bold;
    color: #409eff;
    background-color: #f5f7fa;
    border-bottom: 1px solid #e4e7ed;
  }

  .el-option {
    height: auto;
    line-height: 1.5;
    padding: 8px 20px;

    &:hover {
      background-color: #f5f7fa;
    }

    .el-option__text {
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
  }
}

// 热门国家分组样式
::v-deep .el-select-group:first-child {
  .el-select-group__title {
    color: #f56c6c;
    background-color: #fef0f0;
  }
}
</style>
